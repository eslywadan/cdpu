from dpam.dbtools.db_connection import DbConnection
import dpam.tools.crypto as crypto
import pandas as pd
from dpam.dbtools.sql_buffer import SqlBuffer
#from tools.redis_db import RedisDb ; Use the dsbase's redis 2025/03/24 
from dsbase.tools.redis_db import RedisDb
from dsbase.tools.logger import Logger
from datetime import datetime
from dpam.grpc_cust import clientapival_client as grpc_client


def get_client_info(client_id):
    sql = '''
    SELECT CLIENT_ID, PASSWORD, TYPE, EXPIRY, REGISTRY,PERMISSION 
      FROM ACCOUNT'''
    buf = SqlBuffer(sql).add("CLIENT_ID", client_id)
    cn = DbConnection.default()
    df = pd.read_sql_query(buf.sql, cn)

    info = df.to_dict()
    
    return info


def get_client_info_grpc(client_id):
    
    info = grpc_client.get_clientinfo(client_id)
    
    return info


def get_client_apikey_grpc(client_id,password):
    
    apikey = grpc_client.get_clientapikey(client_id, password)
    
    return apikey


def verified_client_apikey_grpc(apikey):
    
    verified_apikey = grpc_client.get_verified_apikey(apikey)
    
    return verified_apikey


def check_client_id_password(client_id, password,rpsw=True):
    """
        If rpsw (required password flag), return apikey after verifying password and client id is effective
        If not rpsw, return apikey if client id is effective   
    """
    info = get_client_info(client_id)
    type = int(info["TYPE"][0])
    expiry = info["EXPIRY"][0]
    permission = info["PERMISSION"][0]
    registry = info["REGISTRY"][0]    

    # 1st step check if require password, if True, validate pass 
    if rpsw :
        assert len(info["PASSWORD"]) > 0
        Logger.log(f'2.Client info: {info}')
        password_correct = info["PASSWORD"][0]
        check_ok = (password_correct == crypto.crypto_password(type, password))
        Logger.log(f'{client_id} requestes apikey required password checked {check_ok}')
    
    elif not rpsw: 
        check_ok = True
        Logger.log(f'{client_id} requestes apikey pass password checked {check_ok}')
    else: 
        check_ok = False
        Logger.log(f'{client_id} requestes apikey required password checked {check_ok}')

    if check_ok:
        today = datetime.today().strftime("%Y-%m-%d")
        check_ok = expiry > today
        Logger.log(f'{client_id} requestes apikey not expiry checked {check_ok}')

    if check_ok:
        token = crypto.get_account_token(client_id)
        redis = RedisDb.default()
        redis.set(token, f"{client_id}:{permission}:{registry}", expiry_hours=24)
        client_api_key = {"clientid":client_id,"apikey":token,"expiry":24}
        Logger.log(f'{client_id} requestes apikey genereated and cahced at {redis._host}:{redis._port}')
        return client_api_key

    return None


def check_and_log(token=None):

    if token is not None:
        redis = RedisDb.default()
        client_info = redis.get(token)
    if client_info is not None:
        client_id = client_info.split(":")[0]
        permission = client_info.split(":")[1]
        registry = client_info.split(":")[2]
        if permission:
            permission_list = permission.split("|")
            if "QUERY" in permission_list:
                Logger.log(f'Issue request: @{client_id} {token} {registry}')
                return client_info

    Logger.log(f'Deny request: {token}')
    return False

def verify_token_clientid(token, _clientid):
    client_info = check_and_log(token=token)
    if client_info:
        client_id = client_info.split(":")[0]
        if client_id == _clientid: return True
        else: return False
    else: return False


