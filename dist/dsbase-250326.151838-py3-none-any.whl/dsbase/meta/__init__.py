from abc import ABC, ABCMeta

class Ml365(ABC):
    pass


class Ml365Doc(Ml365):
    pass


class Ml365Feature(Ml365):
    featureId:str

class Jobs(ABC):
    pass


class Redis(ABC):
    _keytype=["string","list","hash"]


from .retrain_rdf import RetrainOnto as rt