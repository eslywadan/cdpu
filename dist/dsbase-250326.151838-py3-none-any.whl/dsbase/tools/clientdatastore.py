import os
import io
from os.path import exists
import json
import ast
from  datetime import datetime
import time
import base64
from dsbase.tools.logger import Logger
from dsbase.tools.innodrive import InnoDrive
from dsbase.tools.redis_db import RedisDb


class ClientDataStore():
  """"
  The class equiped InnoDrive and CdsFileMeta with extented methods designed for the client data store.
  - CdsMeta : self.cdsmeta = CdsFileMeta(clientid=clientid) 
  - InnoDrive : self.clientds = self.cdsfmeta.innodrive 

  method get_client_folder : given the client id, will return the folder id created for the client
  method put_file : given enough the source file and target file paths... 
  """
  
  # magic bytes used for recognizing the file type of delegating content to representative obj id    
  magic_bytes_delegate_content_to_rep_obj = b"delegate_content_to_rep_obj"

  def __init__(self,**kwargs):
    """
      clientid -> the client id 
      sourcefilepath -> where path&file
      targetsubpath -> named data entity in full uri path 
    """
    try:
      clientid = kwargs['clientid']
    except:
      return {"status_code":401,"msg":"key word argument has not the required clientid"}
    self.clientid = clientid
    self.cdsfmeta = CdsFileMeta(clientid=clientid)
    self.clientds = self.cdsfmeta.innodrive
    # self.clientds = InnoDrive(clientid=self.clientid)
    self.parentnodeid = self.clientds._nodeid
    self.get_client_folder()

  def get_client_folder(self):
    self._folder_id = self.clientds.cds['id']
    
  def put_file(self, ndeq_meta=False, 
               retrain_raw_meta=False,
               retrain_primary_meta=False, 
               retrain_model_meta=False,
               upload_data_set_meta=False,
               dataservice_data_set_meta=False,
               misc_meta=False,
                 **kwargs):
    """"
    sfilepath = 'full path and the file name specify where the source'
    sfilename = 'source file name'
    tsubpath = 'target sub path where is under the client folder and before the file'
    tfilename = 'target file name'
    example use:
    cds_eng = ClientDataStore(clientid="eng")
    cds_eng.put_file(sfilepath="temp/cds_file_meta_eng.json", 
                     sfilename="cds_file_meta_eng.json",
                     tsubpath="a/b/c/cds_file_meta",
                     tfilename="cds_file_meta_eng.json")

    the enhanced function will check if the fileid existed.
    - check the file id by file name, generally, it is not allowd to be duplicated in the same parent id by name
    - if existed the file id, it will need to lock the file id before upload and un-locked the file after upload completed.
    - if not existed the file id, it is allowed to upload directly
    
    the ndeq_meta flag will be used for appending the cds' meta data. Case when 'True', it will automatically save the required info
    {"ndeq":{'description': 'a meaningful filename', 'ndeqs': '/ds/eng/spcyx/f8/..'}}

    """
    try:
      sfilepath = kwargs['sfilepath']
      sfilename = kwargs['sfilename']
      tsubpath = kwargs['tsubpath']
      tfilename = kwargs['tfilename']
    except:
      return {"status": 400,"msg":"invalid put file arguments"}

    r1 = self.clientds.path_maker(self._folder_id,tsubpath,resetinfo=True) # 2025/3/13 resetinfo set as True to consider continuously upload
    if r1["status"] == "OK": 
      endpointid = r1["endpoint"]
      resp1 = self._upload_file(sfilepath, sfilename, tfilename, endpointid)
      if resp1.status_code == 200: 
        fileid = resp1.json()[0]["id"]
        msg =  {"innodrive":resp1.json()[0]}
      else: 
        Logger.log(resp1)
        return resp1
      update_cds_file_meta = False
      if ndeq_meta: 
        try: ndeq_desc = kwargs["ndeq_desc"]
        except: ndeq_desc = ""
        ndeq_info = {"ndeq":{"ndeqs":f'{tsubpath}/?{tfilename}',"desc":ndeq_desc}}
        msg.update(ndeq_info)
        update_cds_file_meta = True
      if retrain_raw_meta:
        try: retrain_raw_desc = kwargs["retrain_raw_desc"]
        except: retrain_raw_desc = ""
        try: retrain_pipeline = kwargs["retrain_pipeline"]
        except: retrain_pipeline = ""
        retrain_raw_info = {"retrain_raw":{"pipeline":retrain_pipeline,"desc":retrain_raw_desc}}
        msg.update(retrain_raw_info)
        update_cds_file_meta = True
      if retrain_primary_meta:
        try: retrain_primary_desc = kwargs["retrain_primary_desc"]
        except: retrain_primary_desc = ""
        try: retrain_pipeline = kwargs["retrain_pipeline"]
        except: retrain_pipeline = ""
        retrain_primary_info = {"retrain_primary":{"pipeline":retrain_pipeline,"desc":retrain_primary_desc}}
        msg.update(retrain_primary_info)
        update_cds_file_meta = True
      if retrain_model_meta:
        try: retrain_model_desc = kwargs["retrain_model_desc"]
        except: retrain_model_desc = ""
        try: retrain_pipeline = kwargs["retrain_pipeline"]
        except: retrain_pipeline = ""
        retrain_model_info = {"retrain_model":{"pipeline":retrain_pipeline,"desc":retrain_model_desc}}
        msg.update(retrain_model_info)
        update_cds_file_meta = True
      if upload_data_set_meta:
        try: upload_data_set_meta_desc = kwargs["upload_data_set_meta_desc"]
        except: upload_data_set_meta_desc = ""
        upload_data_set_meta_info = {"upload_data_set_meta": upload_data_set_meta_desc}
        msg.update(upload_data_set_meta_info)
        update_cds_file_meta = True
      if dataservice_data_set_meta:
        try: dataservice_data_set_meta_desc = kwargs["dataservice_data_set_meta_desc"]
        except: dataservice_data_set_meta_desc = ""
        dataservice_data_set_meta_info = {"dataservice_data_set_meta": dataservice_data_set_meta_desc}
        msg.update(dataservice_data_set_meta_info)
        update_cds_file_meta = True  
      if misc_meta:
        try: misc_topic = kwargs["misc_topic"]
        except: misc_topic = ""
        try: topic_desc = kwargs["topic_desc"]
        except: topic_desc = ""
        misc_topic_info = {"misc":{"misc_topic":misc_topic,"topic_desc":topic_desc}}
        msg.update(misc_topic_info)
        update_cds_file_meta = True

      if update_cds_file_meta: self.cdsfmeta._update_file_meta(fileid,msg,clientid=self.clientid)
      msg = f"file is saved under {self.clientid}/{endpointid}"
      return { "status":200, "message":msg, "response": resp1}
    else: return r1

  def _upload_file(self, sfilepath, sfilename, tfilename, endpointid):
      """
  
      """
      # fileidexist = self.clientds.get_id_byname_and_parentid(tfilename, endpointid, resetinfo=True)
      
      #if fileidexist["status"] == "OK":
        #lockfileid = fileidexist["objid"]
        #unlocktoken = self.cdsfmeta.getlockfiletoken(lockfileid)
      resp1 = self.clientds.upload_file(sfilename, sfilepath, endpointid, tfilename)
        #self.cdsfmeta.unlockfile(lockfileid, unlocktoken)
      #else: resp1 = self.clientds.upload_file(sfilename, sfilepath, endpointid, tfilename)
      
      return resp1

  def get_file(self, fileid, auto_redirect=True):
    """
    Generally case, consider_ref is not considered. If it is true, it will look into the content of the file and
    check if it is represented by its identical file.
    """
    rf = self.clientds.get_downloadfile(fileid)
    if rf.status_code == 200:
        vr = self.verify_delegate_rep_obj(rf.content)
        if vr["delegate"] and auto_redirect: 
          resp = self.get_file(vr["rep_objid"])
          if resp.status_code == 200: 
            Logger.log(f"get file id : {fileid} is a kind of content redirected to {vr['rep_objid']} ")
            return resp
          else: 
            Logger.log(f"get file id : {fileid} is a kind of content redirected to {vr['rep_objid']} however redirect fail with return code {resp.status_code} ")
    return rf
  
  def verify_delegate_rep_obj_byid(self, objid):
      rf= self.clientds.get_downloadfile(objid)
      if rf.status_code == 200:
        vr = self.verify_delegate_rep_obj(rf.content)
        if vr["delegate"]: return True
        else: False
  
  def verify_delegate_rep_obj(self, rf_content):
      rf_bio = io.BytesIO(rf_content)
      mb = rf_bio.read(len(self.magic_bytes_delegate_content_to_rep_obj))
      if mb == self.magic_bytes_delegate_content_to_rep_obj: # condition matched, indicate it is a representative file
        rep_msg_b = rf_bio.read()
        rep_msg = rep_msg_b.decode('utf-8')
        rep_json = json.loads(rep_msg.replace("'", '"'))
        redirect_objid = rep_json["rep_objid"]
        hash_key = rep_json["hash_key"]
        return {"delegate":True,"rep_objid":redirect_objid,"hash_key":hash_key}
      else:
        return {"delegate":False,"rep_objid":None,"hash_key":None}
  
  def del_file(self, fileid):
    """
    """
    unlocktoken = self.cdsfmeta.getlockfiletoken(fileid)
    rf = self.clientds.del_foldervfile(fileid)
    self.cdsfmeta.unlockfile(fileid, unlocktoken)
    self.cdsfmeta._update_file_meta(fileid,msg={},clientid=self.clientid, del_fileid=True)
    return rf 

    

class CdsFileMeta():
  """
    CDS file meta is the core meta data stored for the interopeation with CDS and the dataservice.

    there are two levels of cdsfilemeta data. The level 1 has the file name cds_file_meta.json is the key value for storing the 
    file id and its clientid generally a whole index by the root of the datastudio.
    Level 2 has the client id file suffix such as 'cds_file_meta_eng.json' storing the required attributes of the file.
    Whenever a read action or write action, check if existed the file at local. If not existed, snapshot a copy from the remote site (innodrive).
    else.

    cds_file_meta.json has the key-value template like {"123": "eng"} for a single dummy record
    cds_file_meta_$client_id.json has the key-value tempate like {"123":{"filename":"a meaningful filename","full_path":"/ds/eng/spcyx/f8/..","client_id":"eng","created_date":":timestamp","modified_date":":timestamp","deleted_date":":timestamp","ndeqs":""}} 


    The remote CDS File Meta is a permenant store and be regenerated if required.
    The local CDS file meta is a copy from the remote permenant store, and should alwayse be check the consistency for read and write action.
    On a read action for a given file id, verify the remote modified date and size. if they are consistent with local,  read directly from the local copy.
    if the remote modified date is latter than local, and the size changed, reload the file from the remote and to save in local and read from the local  

    case when a write action, 1stly compare the size at remote,append only the local copy  

  """
  
  cdsfilemeta = None
  local_cds_file_meta = None
  template_data = None
  innodrive_datetimep = "%Y-%m-%dT%H:%M:%S"

  # redis records three important info for cds meta
  ## (1) the un-lock token by fileid (key: lock^$fileid, value: unlock!$datetime.now().timestamp())
  ## (2) the last_modified timestamp by file id (key:lmd_$fileid,value:$timestamp)
  ## - (1) is used for lock requested instance that will need the un-lock token to un-lock the file. Any file is ready for read/write only if there is no un-lock toekn
  ## - (2) is useful for validating the reqiurement to donwload the newer reserved copy at remote (innodrive). 
  ## (3) "cdsfilemetafileid" on the verify_remote_cds_file_meta()
  redis = RedisDb.default()
  _redis_key_prefix_lastmdate = "lmd_"
  _redis_key_prefix_lock = "lock^"
  _redis_key_prefix_cdsfileid = "cdsfileid_"
  lockfilekey = "cdsLockFileKey"

  cdsfilemetafileid = None

  def __init__(self,clientid):
    """
    instance begin from here, the instance can equipe only query a file's attribute in a light-weight start
    or a local copy if it will need to update meta. It can also init the meta file if needed ( __init_metaifiles__() ) 
    """
    self.clientid = clientid
    self.innodrive = InnoDrive(clientid=clientid)
    self.__init_metafiles__(clientid=clientid) 
    self.set_cdsfilemetafileid()

  def __init_metafiles__(self,clientid='ds'):
    """
      if clientid is 'ds', it will verify the level 1 meta data
      else will verify the level 2 meta
      clientid -> the client id 
    """
    if clientid == 'ds': 
      self.template_data = {"fileid":"clientid"}
      self.cdsfilemeta = 'cds_file_meta.json'
      self.local_cds_file_meta = os.path.join("temp",self.cdsfilemeta)
      
    else: 
      self.template_data = {"abc123":{"filename":"a meaningful filename","full_path":"/ds/eng/spcyx/f8/..","client_id":"","created_date":"","modified_date":"","deleted_date":"","ndeqs":""}}
      self.cdsfilemeta = f'cds_file_meta_{clientid}.json'
      self.local_cds_file_meta = os.path.join("temp",self.cdsfilemeta)   

  def set_cdsfilemetafileid(self):
    """
    the method is only place to set the cdsfilemetafileid
    cdsfilemetafileid is the key file interoperate with cds and innodrive
    Only normal case will persiste or try to reset the satus to normal.
    The normal case describe the existence of the filemeta at innodrive and the file id is the same registered at redis.
    If there is not the file at innodrive side, create it and set the redis cache.
    If there is the file at innodrive side, but lost the redis cache, reset the redis cache key.
    The cdsfilemetafileid is used on updating meta or read the meta

    """
    rediskey = f"{self._redis_key_prefix_cdsfileid}{self.cdsfilemeta}"
    cdsmetafileid = self.redis.get(rediskey)
    if cdsmetafileid is None:
      _ , cdsmetafileid=  self.verify_remote_cds_file_meta()
      self.cdsfilemetafileid = cdsmetafileid
      self.redis.set(rediskey, cdsmetafileid)

    else: 
      val_innodrive_fileid = self.file_info(cdsmetafileid)
      if val_innodrive_fileid.status_code == 200:
         if val_innodrive_fileid.json()[0]['filE_ID'] == cdsmetafileid and val_innodrive_fileid.json()[0]['filE_STATUS'] == 0:
            self.cdsfilemetafileid = cdsmetafileid
         else:
            _ , cdsmetafileid=  self.verify_remote_cds_file_meta()
            self.redis.set(rediskey, cdsmetafileid)
            self.set_cdsfilemetafileid()

  def verify_cds_file_meta(self):
    """
      generally, level cds_file_meta is located under the root of the data studio's node.
      check if existed the file, or created if not.
    """
    rvrcfm = self.verify_remote_cds_file_meta()
    # assert cls.verify_remote_cds_file_meta() in [1, 2]
    # print(f"remote verify status code: {remote_verify_status}")
    ## verify if existed the local side, (1) init the local side if not existed (2) if existed, check the copy of snap shot
    if rvrcfm == [1]: msg1 = 'remote meta file not found, created new and uploaded sucessfully' 
    if rvrcfm == [2]: msg1 = 'remote meta file existed, set the cdsfilemetafileid as responed obj id'
    """
    pull file meta data from cds to init a local cds file meta.
    """
    rvlcfm = self.verify_local_cds_file_meta()
    if rvlcfm == [1,1]: msg2 = "both temp dir & local_cds_file_meta existed"
    if rvlcfm == [1,2]: msg2 = "temp dir existed, but local_cds_file_meta does not, create new"
    if rvlcfm == [2,2]: msg2 = "neither temp dir or local_cds_file_meta existed, create new"
    return f'verify result: {msg1}/n {msg2}'

  def verify_local_cds_file_meta(self):
      """
      returning verified local status case [1,1] : both temp dir & local_cds_file_meta existed 
                                      case [1,2] : temp dir existed, but local_cds_file_meta does not, create new
                                      case [2,1] : generally impossible, it means dose not have temp but has file exited 
                                      case [2,2] : neither temp dir or local_cds_file_meta existed, create new 
      """    
      local_verify_status = []
      try:
        os.listdir("temp")
        local_verify_status.append(1)
      except:
        os.mkdir("temp")
        local_verify_status.append(2)

      if exists(self.local_cds_file_meta):
        local_verify_status.append(1)
      ## ToDo Verify change
      else:
        self.init_cds_file_meta_data()
        local_verify_status.append(2)
      return local_verify_status

  def verify_remote_cds_file_meta(self, also_init_local_cds_file_meta=False):
    """
    returning verified remote status case [1] : init not found and then created new then uploaded sucessfully 
                                     case [2] : init existed and set the cdsfilemetafileid as responed obj id
                                     case [3] : Generally impossible, Unknown error case happened
    """  
    remote_verify_status = []
    ## check remote side - (1) file existed at remote CDS (2) created if not existed (3) set the file id if existed  
    
    r_cdsfilemeta = self.innodrive.get_id_byname_and_parentid(self.cdsfilemeta,self.innodrive.cds["id"], resetinfo=True)
    
    if  r_cdsfilemeta["status"] == 'Not found': 
      remote_verify_status, cdsfilemetafileid = self.init_cds_meta(remote_verify_status)
    elif  r_cdsfilemeta["status"] == 'OK':
      remote_verify_status.append(2)
      cdsfilemetafileid = r_cdsfilemeta['objid']
    else: 
      remote_verify_status.append(3)
      cdsfilemetafileid = None
    if also_init_local_cds_file_meta: self.init_cds_file_meta_data()
    return remote_verify_status, cdsfilemetafileid

  def init_cds_meta(self, remote_verify_status):
      r_upload = self.write_cds_file_meta(filecontent=self.template_data)
      #if r_upload["status"] == "success":
      if r_upload.status_code == 200:
        cdsfilemetafileid = r_upload.json()[0]['id']
      return remote_verify_status.append(1), cdsfilemetafileid

  def write_cds_file_meta(self,filecontent):
      with open(self.local_cds_file_meta, "w") as create_new_cds_file_meta:
        json.dump(filecontent, create_new_cds_file_meta, indent=4)

      # Logger.log(f"local_cds_file_meta : {self.local_cds_file_meta}, self.cdsfilemeta : {self.cdsfilemeta}")
      r_upload = self.innodrive.upload_file(f"{self.cdsfilemeta}", f"{self.local_cds_file_meta}",  self.innodrive.cds["id"], self.cdsfilemeta)
      
      return r_upload

  def init_cds_file_meta_data(self):
    """
    cds file meta is alwayse maintaied a local copy and ensur the consistent with remote reservered copy by 
    checking the last modified date and registed in redis. 
    If they are identical, it will use the local copy directly (self.reload_cdsfilemeta_from_local_copy()). 
    If they are different, it will download from remote and overwrite the local copy, also the laste modified
    date will also be updated.
    only exception case, or the self.cdsfilemetadata will be assiged the value either from remote or local.
    """
    if self.cdsfilemetafileid is None: self.set_cdsfilemetafileid()

  def get_meta_file(self):
    """
    The purpose of getting the unlock key is ensuring the free status of the target file when downloading.
    Or it may get the old snap shot when the file is writting.  
    """

    file = self.innodrive.get_downloadfile(self.cdsfilemetafileid)
    return file
        
  def reload_cdsfmetadata(self):
    """"
    reload begin with local file, or fetch the remote file if local file is not available.
    if return status_code is 200 or 201 generally indicate success, or fail when the return code is 300 301
    """
    unlocktoken = CdsFileMeta.getlockfiletoken(self.cdsfilemetafileid)
    try:
      self._pull_remote_file_meta_to_cds()
      CdsFileMeta.unlockfile(fileid=self.cdsfilemetafileid, unlockfiletoken=unlocktoken)
      Logger.log( f"reload_cdsfmetadata success unlock automatically")
      return {"status_code":200,"msg":"reload success"}
    except:
      CdsFileMeta.unlockfile(fileid=self.cdsfilemetafileid, unlockfiletoken=unlocktoken)
      Logger.log( f"reload_cdsfmetadata fail, unlock automatically")
      return {"status_code":300,"msg":"reload fail"}
    

  def update_meta(self, fileid, msg:dict, del_fileid=False):
    """
    append a cds_file_meta message to the local temp copy and then 
    push back to cds.

    The msg should be in dict format, the process will load the local temp copy,
    update the data and write the file    
    """
    r = self._pull_remote_file_meta_to_cds()

    if r["status"] != 200:
      Logger.log(f"pull remote file meta to cds fail")
      return {"status_code":500,"msg":f"pull remote file meta to cds fail"} 
    
    if (self.cdsfilemetadata is None or ""): 
      Logger.log(f"remote cds file metadata is empty or None ")
      return {"status_code":501,"msg":f"Content from pulling remote file meta to cds is None or empty"}

    with open(self.local_cds_file_meta,"r") as cdsfilemetaf:
        data = json.load(cdsfilemetaf)
        
    if (data is None or ""): 
      Logger.log(f"local cds file meta content is None or empty after 1st load")
      return {"status_code":502,"msg":f"local cds file meta content is None or empty after 1st load"}
    
    if del_fileid: 
      if fileid in data: 
        del data[fileid]
        Logger.log(f"{fileid} is removed from cds file meta content")
    else: 
      data.update({fileid:msg})
      Logger.log(f"{fileid} -  {msg} is updated to cds file meta content")
    
    if (data is None or ""): 
      Logger.log(f"local cds file meta content is None or empty after 1st load and update new message")
      return {"status_code":503,"msg":f"local cds file meta content is None or empty after 1st load and update new message"}

    with open(self.local_cds_file_meta,"w") as cdsfilemetaf:
        json.dump(data, cdsfilemetaf, indent=4)
    
    resp = self.push_local_file_meta_backto_cds(retry=False)
    max_retry = 5
    retry = 0
    while resp.status_code == 'fail' and retry <= max_retry:
      resp = self.push_local_file_meta_backto_cds(retry=False)
      print(f"retry {resp}")
      retry += 1
    if resp.status_code == 'fail': 
      return {"status_code":504,"msg":f"push local cds file meta to remote fail"}
    
    return {"status_code":200,"msg":f"upate message and push local cds file meta to remote successed"}

  def push_local_file_meta_backto_cds(self,retry=True):
    """
    push local file meta back to cds
    """
    sfilename = self.cdsfilemeta
    sfilepath = self.local_cds_file_meta
    #folderid = self.innodrive._nodeid
    folderid = self.innodrive.cds['id']
    tfilename = sfilename
    r_push = self.innodrive.upload_file(sfilename, sfilepath, folderid, tfilename,retry=retry)
    Logger.log(f"push_local_file_meta_backto_cds : sfilename -  {sfilename} sfilepath - {sfilepath} folderid - {folderid}  tfilename - { tfilename}")
    return r_push 

  def _pull_remote_file_meta_to_cds(self):
    """
    pull remote file meta to local cds file, also update the attribute self.cdsfilemetadata.
    generally, it is called by update_meta or a query process. The file lock is thus requested 
    by update method or a query step 
    """
    file = self.get_meta_file()
    if file.status_code == 200:
      Logger.log(f"Debug: pull_remote_file_meta_to_cds success")
      with open(self.local_cds_file_meta,"w") as cdsfilemetaf:
          json.dump(file.json(), cdsfilemetaf, indent=4)
      self.cdsfilemetadata = file.json()
      return {"status":file.status_code, "message":file.text}
    else: 
      Logger.log(f"Debug: pull_remote_file_meta_to_cds fail")
      return {"status":file.status_code, "message":file.text}

  def file_info(self, fileid:str):
    fileinfo = self.innodrive.get_file_info([fileid])
    return fileinfo

  def upsert_cdsfm(self, fileid, msg, del_fileid=False):
    """
    Two steps of upserting (1) ensure consistent between local copy and remote reserved copy 
                           (2) upserting record 
    """
 
    unlocktoken = CdsFileMeta.getlockfiletoken(self.cdsfilemetafileid)
    Logger.log( f"fileid:{fileid} update message {msg}" )
    resp = self.update_meta(fileid, msg, del_fileid)
    if resp["status_code"] == 200: 
      CdsFileMeta.unlockfile(fileid=self.cdsfilemetafileid, unlockfiletoken=unlocktoken)
      Logger.log( f"fileid:{self.cdsfilemetafileid} success unlock automatically")
    else:
      CdsFileMeta.unlockfile(fileid=self.cdsfilemetafileid, unlockfiletoken=unlocktoken)
      Logger.log( f"fileid:{fileid} update message {msg} fail for {resp}, unlock automatically")

  def csearch_fileid(self, qbyl2key:list=None, qbyl3key:list=None,qbyl3keywvalue:dict=None):
      """
      query type:
      (1) query by file id 
      max 3 levels with list index 0, 1, 2 3 for key and value searh
      query example: [["fileid1","fileid2"..],{""},{},{}]
      """
      search_result = {}
      print("search_field use self method")
      reloadcdsfd = self.reload_cdsfmetadata()
      if reloadcdsfd["status_code"] != 200: return reloadcdsfd
      if qbyl2key is not None:
        search_result['qbyl2key'] = self.cquerybylevel2key(qbyl2key)
      if qbyl3key is not None: 
        search_result['qbyl3key'] = self.cquerybylevel3key(qbyl3key)
      if qbyl3keywvalue is not None: 
        search_result['qbyl3keywvalue'] = self.cquerybylevel3keyvalue(qbyl3keywvalue)
      return search_result
  
  def cquerybylevel2key(self, qbylevel2key):
    level1key_with_ql2keys = []
    for key, value in self.cdsfilemetadata.items():
      if isinstance(value, dict): 
        for l2key in qbylevel2key: 
          if l2key in value.keys(): level1key_with_ql2keys.append(key)
    return level1key_with_ql2keys
  
  def cquerybylevel3key(self, qbylevel3key):
      level1key_with_ql3keys = []
      for key, value in self.cdsfilemetadata.items():     # level1 key value ; level 1 key is the fileid
        for nested_key, nested_value in value.items():     # level2 key value ; level 2 key is 'innodrive, ''retrain_primary' etc
          for level3key in qbylevel3key:                   # loop list elements for level 3 key as criterion
            if level3key in nested_value:                  # compare key
              element_with_search_key = nested_value[level3key]
              level1key_with_ql3keys.append(key)
              # print(f"true:{element_with_search_key}")
      return level1key_with_ql3keys
  
  def cquerybylevel3keyvalue(self, qbylevel3keyvalue):
      level1key_with_ql3keyvalue = []
      for key, value in self.cdsfilemetadata.items():     # level1 key value ; level 1 key is the fileid
        for nested_key, nested_value in value.items():     # level2 key value ; level 2 key is 'innodrive, ''retrain_primary' etc
          for level3key, value in qbylevel3keyvalue.items(): # loop list elements for level 3 key as criterion
            if level3key in nested_value and value == nested_value[level3key]: # compare critetia for key & value
              level1key_with_ql3keyvalue.append(key)
              print(f"true:{nested_value}")
      return level1key_with_ql3keyvalue
  
  def _update_file_meta(self, fileid, msg:list, clientid, del_fileid=False):
    """
    generally, it is called after a file is uploaded.
    follow steps are required for updating file meta
    1. validating required message
    2. validating existence of the fileid (get info)
    3. upsert the key value to cds_file_meta.json and cds_file_meta_$clientid.json
    4. update redis (lmd by fileid)
   """
    if msg is None: return
    if msg.__len__() == 0: return
    self.upsert_cdsfm(fileid, msg, del_fileid)

###### class method #####  
  @classmethod
  def getlockfiletoken(cls, fileid):
    """
      type == unlockfiletoken : lock file
           == free : un-lock file    
      any process can lock a file if and only if the filelockkey is none or the value is "free"
      while, if the value of filelockkey is not "free", it must wait till the value is reset to "free"
      The return token is required to unlock the file.  
    """
    filelockkey = f"{cls._redis_key_prefix_lock}{fileid}"
    unlockfiletoken = f"unlock!{datetime.now().timestamp()}"
    if cls.redis.get(filelockkey) == None: cls.redis.set(filelockkey, unlockfiletoken)
    else:
      lockstatus = cls.redis.get(filelockkey)
      accu_wait = 0
      while lockstatus != "free":
          time.sleep(1)
          accu_wait += 1
          lockstatus = cls.redis.get(filelockkey)
          print(f'filelockkey:{filelockkey} / lockstatus:{lockstatus}')
          if accu_wait >= 10: cls.unlockfile(fileid, "force_unlock")
      cls.redis.set(filelockkey, unlockfiletoken)
    return unlockfiletoken
  
  @classmethod
  def unlockfile(cls, fileid, unlockfiletoken):
    """
      only the process that has locked the file will posses the unlockfiletoken, is able to unlock file
      type == unlockfiletoken : lock file
           == free : un-lock file     
    """
    filelockkey = f"{cls._redis_key_prefix_lock}{fileid}"
    tokenvalue = cls.redis.get(filelockkey) 
    if tokenvalue == None: 
      cls.redis.set(filelockkey,"free")
      Logger.log(f"fileid {fileid} has not lock thus unlocked")
      return
    if tokenvalue ==  unlockfiletoken: 
      cls.redis.set(filelockkey,"free")
      Logger.log(f"fileid {fileid} is unlocked by lockkey")
      return
    if unlockfiletoken == "force_unlock": 
      cls.redis.set(filelockkey,"free")
      Logger.log(f"fileid {fileid} is forced unlocked")
      return
    else: 
      Logger.log(f"fileid {fileid} is not unlocked due to given token is not correct")
      return

  @classmethod
  def update_file_meta(cls, fileid, msg:list, clientid):
    """
    generally, it is called after a file is uploaded.
    follow steps are required for updating file meta
    1. validating required message
    2. validating existence of the fileid (get info)
    3. upsert the key value to cds_file_meta.json and cds_file_meta_$clientid.json
    4. update redis (lmd by fileid)
   """
    assert msg is not None
    cdscm = CdsFileMeta(clientid)
    cdscm.upsert_cdsfm(fileid, msg)

######  search classmethod  ######

  @classmethod
  def search_fileid(cls, clientid, qbyl2key:list=None, qbyl3key:list=None,qbyl3keywvalue:dict=None):
      """
      query type:
      (1) query by file id 
      max 3 levels with list index 0, 1, 2 3 for key and value searh
      query example: [["fileid1","fileid2"..],{""},{},{}]
      """
      print("search_field use class method")
      search_result = {}
      cdscm = CdsFileMeta(clientid)
      reloadcdsfd = cdscm.reload_cdsfmetadata()  # will "_pull_remote_file_meta_to_cds() "
      if reloadcdsfd["status_code"] != 200: return {"status_code":300, "msg": f"cannot reload the cds file metadata"}
      if qbyl2key is not None:
        search_result['qbyl2key'] = cls.querybylevel2key(qbyl2key, cdscm)
      if qbyl3key is not None: 
        search_result['qbyl3key'] = cls.querybylevel3key(qbyl3key, cdscm)
      if qbyl3keywvalue is not None: 
        search_result['qbyl3keywvalue'] = cls.querybylevel3keyvalue(qbyl3keywvalue, cdscm)
      return search_result
  
  @classmethod
  def querybylevel2key(cls, qbylevel2key, cdscm):
    level1key_with_ql2keys = []
    for key, value in cdscm.cdsfilemetadata.items():
      if isinstance(value, dict): 
        for l2key in qbylevel2key: 
          if l2key in value.keys(): level1key_with_ql2keys.append(key)
    return level1key_with_ql2keys
  
  @classmethod
  def querybylevel3key(cls, qbylevel3key, cdscm):
      level1key_with_ql3keys = []
      for key, value in cdscm.cdsfilemetadata.items():     # level1 key value ; level 1 key is the fileid
        for nested_key, nested_value in value.items():     # level2 key value ; level 2 key is 'innodrive, ''retrain_primary' etc
          for level3key in qbylevel3key:                   # loop list elements for level 3 key as criterion
            if level3key in nested_value:                  # compare key
              element_with_search_key = nested_value[level3key]
              level1key_with_ql3keys.append(key)
              # print(f"true:{element_with_search_key}")
      return level1key_with_ql3keys
  
  @classmethod
  def querybylevel3keyvalue(cls, qbylevel3keyvalue, cdscm):
      level1key_with_ql3keyvalue = []
      for key, value in cdscm.cdsfilemetadata.items():     # level1 key value ; level 1 key is the fileid
        for nested_key, nested_value in value.items():     # level2 key value ; level 2 key is 'innodrive, ''retrain_primary' etc
          for level3key, value in qbylevel3keyvalue.items(): # loop list elements for level 3 key as criterion
            if level3key in nested_value and value == nested_value[level3key]: # compare critetia for key & value
              level1key_with_ql3keyvalue.append(key)
              print(f"true:{nested_value}")
      return level1key_with_ql3keyvalue
