from dsbase.tools.clientdatastore import CdsFileMeta, ClientDataStore
from dsbase.tools.logger import Logger
import os
from datetime import datetime
from pathlib import Path

currentfilepath = os.path.abspath(__file__)
print(f"current file path:{currentfilepath}")
test_data_path = os.path.join(Path(currentfilepath).parent.parent,'test_data')
print(f"test data path {test_data_path}")


class SelectCDS():
    """
       pass the CDS object for select
    """
    def __init__(self, cds:ClientDataStore):
        self.cds = cds
        self.clienid = cds.clientid
        self.mdlpackrepo = f"/{self.clienid}/mdlpacks"
        self.uploaddatarepo = f"/{self.clienid}/data_store/upload"
        self.reset_meta_info()

    def reset_meta_info(self):
        self.cds.clientds.set_items_all_by_tree(self.cds._folder_id)

    def get_files(self, repository=".", **kwargs):
        fileids = self._get_fileids_by_kw(repository=repository,**kwargs)
        if fileids is None: return None
        files = {}
        for fileid in fileids:
            filename = self.cds.clientds.idname[fileid]
            filepath = self.cds.clientds.get_path_byid(fileid)
            files.update({fileid:[filename,filepath]})
        return files
    
    def get_folders(self, repository=".", **kwargs):
        folderids = self._get_folderids_by_kw(repository=repository,**kwargs)
        if folderids is None: return None
        folders = {}
        for folderid in folderids:
            foldername = self.cds.clientds.idname[folderid]
            folderpath = self.cds.clientds.get_path_byid(folderid)
            folders.update({folderid:[foldername,folderpath]})
        return folders

    def get_mdlpacks_files(self, step=None, sessionid=None, filename=None ):
        """
          The function will return a customized search for mdlpacks repo
        """
        kwargs = {}
        if step != None: kwargs.update({"step":step})
        if sessionid != None: kwargs.update({"sessionid":sessionid})
        if filename != None: kwargs.update({"filename":filename})
        print(f"summary of kwargs: {kwargs}")
        return self.get_files(repository=self.mdlpackrepo, **kwargs)
    
    def get_upload_files(self, data_name=None, version=None):
        """
          The function will return a customized search for data repo
        """
        kwargs = {}
        if data_name != None: kwargs.update({"data_name":data_name})
        if version != None: kwargs.update({"version":version})
        print(f"summary of kwargs: {kwargs}")
        return self.get_files(repository=self.uploaddatarepo, **kwargs)
    
    def _get_fileids_by_kw(self, repository=".", **kwargs):
        """
        1. repository refers the domain in absolute path, if not specified, it will be the root of the CDS by default.
        2. For each item in kw_criteria represent a folder implicit type by key and folder name by value.

        - a folder implicit type generally refers to a class in the related application, such as 'ML_Service' is a folder name 
        that is an instance of mdlpack implicitly. '01_raw' is a folder name that is an instance of step implicitly.

        3. The final result will be interset of all criteria.
        """
        op = {}
        if repository != ".": 
            endpoint_objid_ =  self.get_endpoint_objid(repository)
            if endpoint_objid_ is not None:
                op.update({"repository":self.get_flat_list_file([endpoint_objid_])})
            else: return []    
        for kw, cr in kwargs.items():
            if cr not in self.cds.clientds.nameids.keys(): return []
            op.update({kw:self.get_flat_list_file(self.cds.clientds.nameids[cr])})
        interset = None
        for sn, se in op.items():    
            print(f"criteria exist: {sn} has list len {se.__len__()}")
            if interset == None: interset = set(se)
            interset = interset.intersection(set(se))
        return list(interset)

    def _get_folderids_by_kw(self, repository=".", **kwargs):
        """
        1. repository refers the domain in absolute path, if not specified, it will be the root of the CDS by default.
        2. For each item in kw_criteria represent a folder implicit type by key and folder name by value.

        - a folder implicit type generally refers to a class in the related application, such as 'ML_Service' is a folder name 
        that is an instance of mdlpack implicitly. '01_raw' is a folder name that is an instance of 'step' class implicitly.

        3. The final result will be interset of all criteria.
        """
        op = {}
        if repository != ".": 
            endpoint_objid_ =  self.get_endpoint_objid(repository)
            if endpoint_objid_ is not None:
                op.update({"repository":self.get_flat_list_folder([endpoint_objid_])})
            else: return []    
        for kw, cr in kwargs.items():
            if (cr is None) or (cr == "*") : continue  # Allow not set or * to ignore the criteria
            if cr not in self.cds.clientds.nameids.keys(): return []
            op.update({kw:self.get_flat_list_folder(self.cds.clientds.nameids[cr])})
        interset = None
        for sn, se in op.items():    
            print(f"criteria exist: {sn} has list len {se.__len__()}")
            if interset == None: interset = set(se)
            interset = interset.intersection(set(se))
        return list(interset)

    def get_flat_list_file(self, objids:list):
        """
        Function to return a flat list for downstream files under the folder 
        """
        objids = objids
        #print(f"1.{objids}")
        flat_files_list = []
        for objid in objids:
            #print(f"2. {objid} / {objids}")
            if self.cds.clientds.idtype[objid] == 'F': 
                flat_files_list.append(objid)
                continue
            if objid not in self.cds.clientds.iditemsid.keys(): continue 
            itemsid = self.cds.clientds.iditemsid[objid]
            for itemid in itemsid:
                _file_list = []
                if self.cds.clientds.idtype[itemid] == 'D':
                    _file_list = self.get_flat_list_file([itemid])
                if _file_list.__len__() > 0:
                    for file_id in _file_list: flat_files_list.append(file_id)
                if self.cds.clientds.idtype[itemid] == 'F':
                    flat_files_list.append(itemid)
        return flat_files_list
    
    def get_flat_list_folder(self, objids:list):
        """
        Function to return a flat list for downstream folders. 
        If the input objectids has only one object, it will return its downstrem folders.
        If the input objectids has more than one objects,  it will return all downstrem folders belong to those objects.
        """
        objids = objids
        #print(f"1.{objids}")
        flat_folders_list = []
        for objid in objids:
            #print(f"2. {objid} / {objids}")
            if self.cds.clientds.idtype[objid] == 'F': 
                continue
            flat_folders_list.append(objid)
            if objid not in self.cds.clientds.iditemsid.keys(): continue
            itemsid = self.cds.clientds.iditemsid[objid]
            for itemid in itemsid:
                _folder_list = []
                if self.cds.clientds.idtype[itemid] == 'D':
                    flat_folders_list.append(itemid)
                    _folder_list = self.get_flat_list_folder([itemid])
                    if _folder_list.__len__() >0 :
                        for folder_id in _folder_list: flat_folders_list.append(folder_id)
                
        return flat_folders_list
    
    def get_endpoint_objid(self,repository):
        """
            repository is the full path name in default node.
            the logic used for validating the endpoint meets the repository:
            1. get the endpoint's object name of the repository
            2. Use the endpoint's name to get the objids.
            3. If it has only one objid, return the object id 
            4. If it has multiple objids, get the path by get_path_byid for each objid.
            5. return the object id whose path is identical with the repositiory
            return conditions:
            (1) return root
            (2) return None (the repository is not correct)  
        """
        endpoint_obj_name = repository.split("/")[-1]
        if endpoint_obj_name == "": return None   
        if endpoint_obj_name not in self.cds.clientds.nameids.keys(): return None
        endpoint_obj_id = []
        for objid in self.cds.clientds.nameids[endpoint_obj_name]:
            if repository == self.cds.clientds.get_path_byid(objid): 
                endpoint_obj_id.append(objid)
        
        if endpoint_obj_id.__len__() != 1: return None
        else: return endpoint_obj_id[0]


class DataStore():
    data_store_path="/data_store"
    upload_data_store_path = "/data_store/upload"
    dataservice_data_store_path = "/data_store/dataservice"

    def __init__(self,clientid="eng"):
        self.clientid = clientid
        kwargs = {"clientid":clientid}
        self.cds = ClientDataStore(**kwargs)
        self.idv = self.cds.clientds
        self._check_data_store()

    def _check_data_store(self):
        self.scds = SelectCDS(self.cds)
        resps = []
        if self.scds.get_endpoint_objid(self.data_store_path) != None: 
            if self.scds.get_endpoint_objid(self.upload_data_store_path) == None:
                resps.append(self.idv.path_maker(self.cds._folder_id, self.dataservice_data_store_path, resetinfo=True))
            if self.scds.get_endpoint_objid(self.dataservice_data_store_path) == None: 
                resps.append(self.idv.path_maker(self.cds._folder_id, self.upload_data_store_path, resetinfo=True))
        else:
            resps.append(self.idv.path_maker(self.cds._folder_id, self.upload_data_store_path, resetinfo=True))
            resps.append(self.idv.path_maker(self.cds._folder_id, self.dataservice_data_store_path, resetinfo=True))
        
        if resps.__len__() > 0:
            for resp in resps:
                if resp["status"] == "OK": pass
                else: return {"status":"Error","message":"check data store fail"}
        return {"status":"OK","message":"check data store Sucessfully"}

    def putdata(self, dataset,version,sourcedatasetpath, sourcefilename=None, _data_store_path = 'upload',**inkwargs):
        """"
        putdata is going to new if the dataset and version does not exists. 
        or update if existed the same dataset and version.
        **inkwargs{"meta_file":$file_name, "change_log":$file_name,
                    "meta_data":{"columns_num":20,"row_num":"202"}}
        "meta_file" and "change_log" are optional kws expexted on the same path with dataset.
        These data will be automatically upload into the same location if existed. 
        sample inkwargs= {"meta_file":meta_dataset, "change_log":change_dataset,
                    "meta_data":{"columns_num":20,"row_num":"202"}}
        return message spec:
        { "h1":<message header, with fuction name and message time>,
          "ack1":<dataset name>
          "ack2":<>..}
        Quick way to get the sucessfully uploaded object id
         -> check 'ack5.1.1' for soruce data, 'ack6.1.1' for meta file and 'ack7.1.1' for change file. 
        
        changelog 2025/3/13 
           1. must be able to seperate upload file and exchanged from data service
           2. can know the purpose of dataset used in ml365, tag with a features list
              ml365_features:['F1.1', 'F2.1', 'F4.1', 'F5.1'] 
         - add arg _data_store_path with default 'upload'
         - refactoring to split function put_upload_data and put_dataservice_data according to the arg
        """
        msg = {"h1":f"Data Store put file Message time:{datetime.now().strftime('%Y/%m/%d:%H:%M:%S')}"}
        
        if sourcefilename is None: 
            sourcefilename = dataset
            msg.update(**{"ack1":f"source file name is set as dataset name:{dataset}"}) # ack01
        
        inkwargs = inkwargs
        if _data_store_path == "upload":
            return self.put_upload_data(dataset, version, sourcedatasetpath, sourcefilename, msg, **inkwargs)

        if _data_store_path == "dataservice":
            return self.put_dataservice_data(dataset, version, sourcedatasetpath, sourcefilename, msg, **inkwargs)

    def put_upload_data(self, dataset, version, sourcedatasetpath, sourcefilename, msg, **inkwargs):
        targetfilename = sourcefilename
        sourcefilepath = os.path.join(sourcedatasetpath, sourcefilename)
        meta_file = None
        change_file = None
        meta_data = None 
        for kw, value in inkwargs.items():
            if kw == "meta_file": 
                meta_file = value
                msg.update(**{"ack2": f"Has meta_file:{meta_file}"}) # ack02
            if kw == "change_log": 
                change_file = value
                msg.update(**{"ack3":f"Has change_file: {change_file}"}) # ack03
            if kw == "meta_data": 
                meta_data = value
                msg.update(**{"ack4": f"Has meta_data:{meta_data}"}) # ack04

        outkwargs = {}
        outkwargs['upload_data_set_meta_desc']={"dataset":dataset,"meta_data":meta_data}
        outkwargs['sfilename'] = sourcefilename
        outkwargs['tsubpath']=f"{self.upload_data_store_path}/{dataset}/{version}"
        outkwargs['tfilename']=targetfilename

        if os.path.exists(sourcefilepath):
            outkwargs['sfilepath'] = sourcefilepath
            resp = self.cds.put_file(upload_data_set_meta=True,**outkwargs)
            msg.update(**{"ack5":f"sourcefilepath:{sourcefilepath} archived to innodrive with status code {resp['response'].status_code}"}) # ack05 success on archiving source file to store
            if resp['response'].status_code == 200:
                msg.update(**{"ack5.1":resp['response'].json()[0]}) # ack5.1 success on archiving source file to store
                msg.update(**{"ack5.1.1":resp['response'].json()[0]['id']}) # ack5.1.1 archived object id such as 'f5752865-b813-4442-90e7-c31018514d91'
            else:msg.update(**{"ack5.0.1":resp['response'].text}) # ack05.2 fail on archiving source file to store
        else: msg.update(**{"ack5.0.2":f"sourcefilepath:{sourcefilepath} is going archived to innodrive while file not found!"})

        if meta_file != None:
            metafilepath = os.path.join(sourcedatasetpath, meta_file)
            if os.path.exists(metafilepath): 
                outkwargs['sfilepath'] = metafilepath
                outkwargs['sfilename'] = meta_file
                outkwargs['tfilename']= meta_file
                resp = self.cds.put_file(upload_data_set_meta=True,**outkwargs)
                msg.update(**{"ack6":f"metafilepath:{metafilepath} archived to innodrive path: {outkwargs['tsubpath']}/{outkwargs['tfilename']}"})
                if resp['response'].status_code == 200:
                    msg.update(**{"ack6.1":resp['response'].json()[0]}) # ack06.1 success on archiving source file to store
                    msg.update(**{"ack6.1.1":resp['response'].json()[0]['id']}) # ack6.1.1 archived object id such as 'f5752865-b813-4442-90e7-c31018514d91'
                else: msg.update(**{"ack6.0.1":resp['response'].text}) # ack06.2 fail on archiving source file to store
            else: 
                msg.update(**{"ack6.0.2":f"metafilepath:{metafilepath} is going archived to innodrive while file not found!"})

        if change_file != None:
            changefilepath = os.path.join(sourcedatasetpath, change_file)
            if os.path.exists(changefilepath): 
                outkwargs['sfilepath'] = changefilepath
                outkwargs['sfilename'] = change_file
                outkwargs['tfilename']= change_file
                resp = self.cds.put_file(upload_data_set_meta=True,**outkwargs)
                msg.update(**{"ack7":f"changefilepath:{changefilepath} archived to innodrive path: {outkwargs['tsubpath']}/{outkwargs['tfilename']}"})
                if resp['response'].status_code == 200: 
                    msg.update(**{"ack7.1":resp['response'].json()[0]})
                    msg.update(**{"ack7.1.1":resp['response'].json()[0]['id']}) # ack7.1.1 archived object id such as 'f5752865-b813-4442-90e7-c31018514d91'
                else: msg.update(**{"ack7.0.1":resp['response'].text}) # ack07.2 fail on archiving source file to store
            else: 
                msg.update(**{"ack7.0.2":f"changefilepath:{changefilepath} is going archived to innodrive while file not found!"})
        
        return msg

    def put_dataservice_data(self, dataset, version, sourcedatasetpath, sourcefilename, msg, **inkwargs):
        msg = {"h1":f"Data Store put file Message time:{datetime.now().strftime('%Y/%m/%d:%H:%M:%S')}"}
        if sourcefilename is None: 
            sourcefilename = dataset
            msg.update(**{"ack1":f"source file name is set as dataset name:{dataset}"}) # ack01
        targetfilename = sourcefilename
        sourcefilepath = os.path.join(sourcedatasetpath, sourcefilename)
        meta_file = None
        change_file = None
        meta_data = None
        for kw, value in inkwargs.items():
            if kw == "meta_file": 
                meta_file = value
                msg.update(**{"ack2": f"Has meta_file:{meta_file}"}) # ack02
            if kw == "change_log": 
                change_file = value
                msg.update(**{"ack3":f"Has change_file: {change_file}"}) # ack03
            if kw == "meta_data": 
                meta_data = value
                msg.update(**{"ack4": f"Has meta_data:{meta_data}"}) # ack04

        outkwargs = {}
        outkwargs['dataservice_data_set_meta_desc']={"dataset":dataset,"meta_data":meta_data}
        outkwargs['sfilename'] = sourcefilename
        outkwargs['tsubpath']=f"{self.dataservice_data_store_path}/{dataset}/{version}"
        outkwargs['tfilename']=targetfilename

        if os.path.exists(sourcefilepath):
            outkwargs['sfilepath'] = sourcefilepath
            resp = self.cds.put_file(dataservice_data_set_meta=True,**outkwargs)
            msg.update(**{"ack5":f"sourcefilepath:{sourcefilepath} archived to innodrive with status code {resp['response'].status_code}"}) # ack05 success on archiving source file to store
            if resp['response'].status_code == 200:
                msg.update(**{"ack5.1":resp['response'].json()[0]}) # ack5.1 success on archiving source file to store
                msg.update(**{"ack5.1.1":resp['response'].json()[0]['id']}) # ack5.1.1 archived object id such as 'f5752865-b813-4442-90e7-c31018514d91'
            else:msg.update(**{"ack5.0.1":resp['response'].text}) # ack05.2 fail on archiving source file to store
        else: msg.update(**{"ack5.0.2":f"sourcefilepath:{sourcefilepath} is going archived to innodrive while file not found!"})

        if meta_file != None:
            metafilepath = os.path.join(sourcedatasetpath, meta_file)
            if os.path.exists(metafilepath): 
                outkwargs['sfilepath'] = metafilepath
                outkwargs['sfilename'] = meta_file
                outkwargs['tfilename']= meta_file
                resp = self.cds.put_file(upload_data_set_meta=True,**outkwargs)
                msg.update(**{"ack6":f"metafilepath:{metafilepath} archived to innodrive path: {outkwargs['tsubpath']}/{outkwargs['tfilename']}"})
                if resp['response'].status_code == 200:
                    msg.update(**{"ack6.1":resp['response'].json()[0]}) # ack06.1 success on archiving source file to store
                    msg.update(**{"ack6.1.1":resp['response'].json()[0]['id']}) # ack6.1.1 archived object id such as 'f5752865-b813-4442-90e7-c31018514d91'
                else: msg.update(**{"ack6.0.1":resp['response'].text}) # ack06.2 fail on archiving source file to store
            else: 
                msg.update(**{"ack6.0.2":f"metafilepath:{metafilepath} is going archived to innodrive while file not found!"})

        if change_file != None:
            changefilepath = os.path.join(sourcedatasetpath, change_file)
            if os.path.exists(changefilepath): 
                outkwargs['sfilepath'] = changefilepath
                outkwargs['sfilename'] = change_file
                outkwargs['tfilename']= change_file
                resp = self.cds.put_file(upload_data_set_meta=True,**outkwargs)
                msg.update(**{"ack7":f"changefilepath:{changefilepath} archived to innodrive path: {outkwargs['tsubpath']}/{outkwargs['tfilename']}"})
                if resp['response'].status_code == 200: 
                    msg.update(**{"ack7.1":resp['response'].json()[0]})
                    msg.update(**{"ack7.1.1":resp['response'].json()[0]['id']}) # ack7.1.1 archived object id such as 'f5752865-b813-4442-90e7-c31018514d91'
                else: msg.update(**{"ack7.0.1":resp['response'].text}) # ack07.2 fail on archiving source file to store
            else: 
                msg.update(**{"ack7.0.2":f"changefilepath:{changefilepath} is going archived to innodrive while file not found!"})
        
        return msg

    def get_objids_path_by_nameversion(self, dataset=None, version=None, category="upload"):
        msg = {"get object ids and paths ":f"has dataset: {dataset} / version: {version} / category: {category}"}
        if dataset != None or version != None:
            if category == "upload"      : repository = f"/{self.clientid}{self.upload_data_store_path}"
            if category == "dataservice" : repository = f"/{self.clientid}{self.dataservice_data_store_path}"
            r_dobjids = self.scds.get_folders(repository=repository,**{"dataset":dataset,"version":version})
            r_fobjids = self.scds.get_files(repository=repository,**{"dataset":dataset,"version":version})
            msg.update(**{"FolderObjectID":r_dobjids})
            msg.update(**{"FileObjectID":r_fobjids})
            return msg
        return msg.update(**{"Error":"None of dataset or version criteria is set"})
    
    def get_data_by_nameversion(self, local_file_path, dataset=None, version=None, category="upload"):
        """
        """
        msg = {"get data ":f"has dataset: {dataset} / version: {version} / local_file_path: {local_file_path}/ category: {category}"}
        print(msg)
        if not os.path.exists(local_file_path):
            msg.update(**{"local_file_path": f"{local_file_path} dose not exist"})
            print(msg) 
            return msg

        if dataset != None or version != None:
            if category == "upload"      : repository = f"/{self.clientid}{self.upload_data_store_path}"
            if category == "dataservice" : repository = f"/{self.clientid}{self.dataservice_data_store_path}"
            _msg = self.get_objids_path_by_nameversion(dataset=dataset, version=version, category=category) 
            r_dobjid = _msg["FolderObjectID"]
            path_ = local_file_path
            for _ , item in r_dobjid.items():
                for d in item[1].split("/"):
                    path_ = os.path.join(path_, d)
                    if os.path.exists(path_): continue
                    os.mkdir(path_)

            r_fobjids = _msg["FileObjectID"]
            
            for objid, _ in r_fobjids.items():
                _msg = self.get_data_byobjid(path_, objid)
                msg.update(_msg)

        return msg
    
    def get_data_byobjid(self, local_file_path, objid=None): 
        """
        """
        msg = {}
        msg.update(**{"get data by object id":f"has objid: {objid} and local_file_path: {local_file_path} set"})
        print(msg)
        
        if self.scds.cds.clientds.idtype[objid] == "F":
            msg_ = self.get_single_file(objid, local_file_path)
            msg.update(msg_)
        elif self.scds.cds.clientds.idtype[objid] == "D":
            itemids = self.scds.cds.clientds.iditemsid[objid]
            for itemid in itemids:                
                msg_ = self.get_single_file(itemid, local_file_path)
                msg.update(msg_)
                print(msg)
        else: 
            msg.update(**{"given objid has errornous type":self.scds.cds.clientds.idtype[objid]})
            print(msg)
        return msg
    
    def get_single_file(self, objid, local_file_path):
        msg = {}
        msg.update(**{"get data by object id for a single file":f"has objid: {objid} and local_file_path: {local_file_path} set"})
        r_file = self.cds.get_file(objid)
        file_name = self.cds.clientds.idname[objid]
        if r_file.status_code == 200 and local_file_path != False:
            if os.path.exists(local_file_path):
                local_file_full_path = os.path.join(local_file_path,file_name) 
                msg.update(**{f"file obj {objid} is downloaded to ": local_file_full_path})
                resp = self.download_data_file(r_file, local_file_full_path)
                if resp["status_code"] == 200:
                    msg.update(**{f"objid existed the file name {file_name} and downloaded to local file path":f"{local_file_path}"})
                else:
                    msg.update(**{f"objid existed the file name {file_name} but fail on downloading to local file path":f"{local_file_path} with {resp}"})
            
            else:  msg.update(**{f"objid existed the file name {file_name} but given local file path":f"{local_file_path} does not exist"})
        else:   msg.update(**{f"objid existed the file name {file_name} ":f"cannot be fetched with message {r_file}"})
    
        return msg
    
    def download_data_file(self, resp, local_file):
        """"""
        if resp.status_code == 200:
            with open(local_file, "wb") as file:
                for chunk in resp.iter_content(chunk_size=1024):
                    if chunk:
                        file.write(chunk)
            return {"status_code":200,"msg":f"Given response object has written to {local_file}"}
        else: return {"status_code":resp.status_code,"msg":f"Given response object has status code {resp.status_code}"}


    def get_list_data(self): #TODO
        data= data
        return data
    
def test_data_store():
    """
    >> dir(ds.cds)
    ['__class__', '__delattr__', '__dict__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__', '__gt__',
    '__hash__', '__init__', '__init_subclass__', '__le__', '__lt__', '__module__', '__ne__', '__new__', '__reduce__', '__reduce_ex__', 
    '__repr__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', '__weakref__', '_folder_id', '_upload_file', 'cdsfmeta', 
    'clientds', 'clientid', 'del_file', 'get_client_folder', 'get_file', 'magic_bytes_delegate_content_to_rep_obj', 'parentnodeid', 
    'put_file', 'verify_delegate_rep_obj', 'verify_delegate_rep_obj_byid']
    >>> dir(ds.cds.clientds)
    ['__class__', '__delattr__', '__dict__', '__dir__', '__doc__', '__eq__', '__format__', '__ge__', '__getattribute__',
    '__gt__', '__hash__', '__init__', '__init_subclass__', '__le__', '__lt__', '__module__', '__ne__', '__new__', 
    '__reduce__', '__reduce_ex__', '__repr__', '__setattr__', '__sizeof__', '__str__', '__subclasshook__', '__weakref__',
    '_add_folder_url', '_apikey_dur', '_apikey_st', '_apilist', '_clientstore', '_delete_file_url', '_get_apikey_url',
        '_get_download_file_url', '_get_file_info_url', '_get_item_tree_url', '_get_items_url', '_getkey_timeout', '_identity',
        '_inodrvhost', '_level1', '_nodeid', '_rename_url', '_tempfold', '_upload_files_url', 'add_folder', 'add_items_2levels',
            'apikey', 'cds', 'create_clientds_ifnot_exist', 'deduct_items_single', 'del_file', 'del_folder', 'del_foldervfile', 
            'files_compare', 'files_similarity_inorder_lines', 'files_similarity_unorder_lines', 'get_apikey', 'get_byte_byid', 
            'get_config_level1_items', 'get_downloadfile', 'get_downloadfileurl', 'get_file_info', 'get_id_byname', 
            'get_id_byname_and_parentid', 'get_idd_byname', 'get_item_tree', 'get_items', 'get_name_byid', 'get_node_items', 
            'get_parent_byid', 'get_path_byid', 'get_type_byid', 'idbyte', 'identity_check_by_hash', 'iditemsid', 'iditemsname', 
            'idname', 'idparent', 'idpath', 'idtype', 'irequests', 'make_path', 'nameaddid', 'namedeductid', 'nameids', 'nameidshowdetail', 
            'path_maker', 'read_item_tree', 'rename_file', 'rename_folder', 'rename_foldervfile', 'rename_items_single', 
            'set_client_items_all', 'set_items_all', 'set_items_all_by_tree', 'set_node_items_all', 'upload_file', 'val_apikey']
    """
    clientid = "test_data_store"
    ds = DataStore(clientid=clientid)
    # data_store folder should not exist, this SelectCDS should return []
    scds = SelectCDS(ds.cds)
    assert scds.get_folders(**{"fldername1":"data_store","fldername2":"upload"}) != {}
    # test upload data
    dataset = "ML_Service_training"
    version = "init"
    filename = "ML_Service_training.csv"
    s_datasetpath = os.path.join(test_data_path,dataset, version)
    l_datasetpath = os.path.join(test_data_path,"local")
    assert os.path.exists(s_datasetpath)
    inkwargs = {"meta_file":"meta_file.json", "meta_data":{"data_set": "ML_Service_Training","columns_num": 33,"rows_num": 239, "create_time":"20240820133605"}}
    ds.putdata(dataset=dataset, version=version, sourcedatasetpath=s_datasetpath, sourcefilename=filename, **inkwargs)

    version = "20240820133835"
    s_datasetpath = os.path.join(test_data_path,dataset, version)
    assert os.path.exists(s_datasetpath)
    inkwargs = {"meta_file":"meta_file.json","change_log":"change_file.json", "meta_data":{"data_set": "ML_Service_Training","columns_num": 33,"rows_num": 237, "create_time":"20240820133835"}}
    ds.putdata(dataset=dataset, version=version,sourcedatasetpath=s_datasetpath, sourcefilename=filename, **inkwargs)

    version = "20240820134825"
    s_datasetpath = os.path.join(test_data_path,dataset, version)
    assert os.path.exists(s_datasetpath)
    inkwargs = {"meta_file":"meta_file.json","change_log":"change_file.json", "meta_data":{"data_set": "ML_Service_Training","columns_num": 33,"rows_num": 234, "create_time":"0240820134825"}}
    ds.putdata(dataset=dataset, version=version,sourcedatasetpath=s_datasetpath, sourcefilename=filename, **inkwargs)
    msg = ds.get_objids_path_by_nameversion(dataset="ML_Service_training", version="init")
    msg = ds.get_objids_path_by_nameversion(dataset="ML_Service_training")
    msg = ds.get_data_by_nameversion(local_file_path=l_datasetpath,dataset="ML_Service_training", version="init")
    
    # final test to del the CDS for clientid
    ds.cds.clientds.del_folder((ds.cds._folder_id))


def test_mdlpacks_repo():
    ds = DataStore()
    sds = SelectCDS(ds.cds)
    assert sds.get_endpoint_objid(repository="/eng/mdlpacks") is not None
    assert sds.mdlpackrepo == "/eng/mdlpacks"
    # arbitary repository and criteria
    repository = "/eng/mdlpacks/Graffiti"
    kwargs = {"filename":"X_test.pq"}
    sds.get_files(repository,**kwargs)
    sds._get_fileids_by_kw(repository,**kwargs)
    sds.get_mdlpacks_files(sessionid="2024-05-14T05.15.10.340Z", step="03_primary", filename="X_test.pq")

def test_data_upload_repo_exists():
    ds = DataStore()
    sds = SelectCDS(ds.cds)
    assert sds.get_endpoint_objid(repository="/eng/data_store/upload") is not None

