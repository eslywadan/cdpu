from logging.config import valid_ident
from flask import request, render_template
import ndeq.ttlsap.fab_proc as fab_proc
import ndeq.ttlsap.edc_data as edc_data
import ndeq.ttlsap.edc_dim as edc_dim
import ndeq.ttlsap.spc_dim as spc_dim
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dsbase.tools.redis_db import RedisDb, CacheType
from dsbase.tools.logger import Logger
import dsbase.tools.reset_config as reset_config
from dsbase.tools.cache_key import get_cache_key
from dsbase.tools.response_handler import * 
from dsbase.grpc_cust.clientapival_client import get_clientapikey, get_verified_apikey
from dsbase.tools.response_handler import InvalidUsage
from dsbase.tools.config_loader import ConfigLoader
import requests
import re

def process_login(clientId=None, password=None):     
    if clientId is None:
        if "clientId" in request.headers:
            clientId = request.headers["clientId"]
        else:
            clientId = request.args.get('clientId')
    if password is None:
        if "password" in request.headers:
            password = request.headers["password"]
        else:
            password = request.args.get('password')

    apikey = get_clientapikey(clientId, password)

    if apikey.expiry == "1900-01-01":
        Logger.log(f"Client id {clientId} fail on process_login")
        #return JSNError(f"Client Id {clientId} or password {password} is not correct.",status_code=401)
        return { "status_code": 401, "apikey":None}
    else:
        Logger.log(f'Issue request: {clientId}, {request.method}, {request.url}')
        return {"status_code":200, "apikey":apikey.apikey}


def dummy_check_and_log():
    return  {"status":True,"apikey":"given_token"}


def check_and_log(ignore_token=False, authby="apikey"):
    """
        2025.03.26 add authby argument with 'apikey' as default
        case weh authby == 'ssotoken', will call the accountman's api (defined in config.json)
        to get the authenticated client id 
    """
    if ignore_token:
        Logger.log(f'Issue request: {request.method}, {request.url}')
        return True
   
    if authby == "ssotoken":
        request_permission = request.args.get("request_permit")
        if request_permission is None: request_permission = '/ds/carux/apds'
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith('Bearer '):
            # Extract apikey from header
            given_token = auth_header.split(" ")[1]
            verify_result = get_apikey_by_ssotoken(request_permission, given_token)
            if 'clientid' and 'apikey' in verify_result.keys():
                verify_result.update({"status":True})
                return verify_result
            else:
                verify_result.update({"status":False,"error_msg":verify_result["message"]})    
                return verify_result
    
    given_token = None

    if "apikey" in request.headers: 
        given_token = request.headers["apikey"]
    # Extract authorization heder
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith('Bearer '):
        # Extract apikey from header
        given_token = auth_header.split(" ")[1]
        Logger.log(f"giveb token is via auth header in Bearer {given_token}")
    if request.args.get('token'):
        given_token = request.args.get('token')
    client_type = 'BLOCK'
    if given_token is not None:
        given_token = given_token.strip('"')
        token_info =  get_verified_apikey(given_token)
        if token_info.assertion == 'False':
            return {"status":1,"error_msg":"Given token is not correct! (無法辨識是哪一個 client id)","status_code":401}
        client_type = token_info.assertion.split(":")[1]
        Logger.log(f"{token_info} / client type {client_type}")

    if client_type == "BLOCK":
        return {"status":9,"error_msg":"Given token has found the client is blocked from requesting data services","status_code":403}

    if token_info.apikey == given_token:
        if token_info.assertion is not None:
            registry = token_info.assertion.split(":")[2]
            granted = validate_ds_permission(registry,request.url)
            Logger.log(f'Issue request: @{given_token}, {request.method}, {request.url}, {token_info.assertion}')
            if granted == "Permit":
                client_id = token_info.assertion.split(":")[0]
                client_prev = token_info.assertion.split(":")[2]
                return {"status":True,"apikey":given_token, "client_id":client_id}
            else:
                return {"status":2,"error_msg":"Given token has not the permission for requesting data services (該 client id 沒有此資料服務的使用權限)","status_code":403}

    Logger.log(f'Deny request: {request.method}, {request.url}')

def get_apikey_by_ssotoken(request_permision, ssotoken):
    authserver = ConfigLoader.config("accountman")
    url=f"http://{authserver['connection']['host']}:{authserver['connection']['port']}{authserver['api']['getUserPermitsClientApikey']}"
    headers = {
        "Authorization": f"Bearer {ssotoken}",
        "Content-Type": "application/json"
    }
    
    Logger.log(f"get_apikey_by_ssotoken {url}")
    response = requests.get(url, headers=headers)
    Logger.log(f"get_apikey_by_ssotoken {url} with status code {response.status_code}")
    try:
        Logger.log(f"Response JSON:{response.json()}")
        return response.json()
    except ValueError:
        Logger.log(f"Response Text: {response.text}") 
        return response.text

def validate_ds_permission_legacy(registry, url):
    """ legacy function compared the nde and registry str in sequentially without wildcard
    """
    nde =url.partition("/ds")[2]
    permit = []
    if len(registry.strip())==0:  return "No Permit"
    for reg in registry.split(","): 
        if reg.startswith("-"):
            # Negative element, match pattern is not allowed
            if nde.startswith(reg.partition("-")[2]):permit.append(False)

        if not reg.startswith("-"):
            if nde.startswith(reg): permit.append(True)
            # consider the * as wild card and split into front and end part
            # only the first * is consider, the 2nd * will be regarded as normal string
                

    if permit.__contains__(False) or permit.__len__() == 0:
        return "No Permit"
    else :
        return "Permit"

def validate_ds_permission(registry, url):
    """
        The validation function will consider the wild card in the reg string
        A registry may be empty or one to several reg string seperated in "," such as "/eng/ispec/define/F8,/eng/ispec/spec/F8"
    """
    nde =url.partition("/ds")[2]
    permit = []
    # case registry value is empty
    if len(registry.strip())==0:  return "No Permit"
    # case registry is not empty and contains one or several regs
    for reg in registry.split(","): 
        if reg.startswith("-"): 
            reg_type = False
            reg_pat = reg.lstrip("-")
        else: 
            reg_type = True
            reg_pat = reg
        pat_match = re.search(reg_pat.replace("*",".+"),nde) 
        print(f"reg_type: {reg_type}/ reg_pat:{reg_pat}")
        print(f"pat_match: {pat_match}")
        if pat_match is not None and pat_match.start() == 0: permit.append(reg_type)

    if permit.__len__() == 0 or permit.__contains__(False):
        return "No Permit"
    else :
        return "Permit"            


#先檢查cache，有則回傳，沒有則建立
def process_req_fab_proc():
    if not check_and_log()["status"]:
        return JSNError("Token is missing or token is not correct. Please call Login API to get a new token.")
    
    cache_type = RedisDb.cache_type()
    if cache_type == CacheType.AUTO:
        list = find_cache()
        if list is None:
            list = get_fab_proc()
            set_cache(list)
    elif cache_type == CacheType.READONLY:
        list = find_cache()
    elif cache_type == CacheType.IGNORE:
        list = get_fab_proc()
    elif cache_type == CacheType.RENEW:
        list = get_fab_proc()
        set_cache(list)
    elif cache_type == CacheType.BUILD:
        list = get_fab_proc()
        set_cache(list)
        list = []

    return JSNResponse(list)


def get_fab_proc():
    if request.endpoint == 'get_fab_list':
        list = fab_proc.get_fab_list()
    else:
        fab = request.args.get('fab')
        list = fab_proc.get_proc_list(fab)

    return list


#依據cache type存取資料
def process_req(fab=None, process=None):
    if not check_and_log()["status"]:
        return JSNError("Token is missing or token is not correct. Please call login API to get a new token.")
    
    cache_type = get_cache_type()
    if cache_type == CacheType.AUTO:
        list = find_cache()
        if list is None:
            list = get_list_from_db(fab, process)
            set_cache(list)
    elif cache_type == CacheType.READONLY:
        list = find_cache()
        if list is None: list = []
    elif cache_type == CacheType.IGNORE:
        list = get_list_from_db(fab, process)
    elif cache_type == CacheType.RENEW:
        list = get_list_from_db(fab, process)
        set_cache(list)
    elif cache_type == CacheType.BUILD:
        list = get_list_from_db(fab, process)
        set_cache(list)
        list = [0]*len(list)

    return JSNResponse(list)


def get_list_from_db(fab, process):
    func_name = request.endpoint
    args = get_args()
    if 'spc' in func_name:
        func = getattr(spc_dim, func_name)
    else:
        func = getattr(edc_dim, func_name)

    list = func(fab, process, **args)
    return list


#不使用cache
def process_req_no_cache(fab=None, process=None, equipment=None):
    if not check_and_log()["status"]:
        return JSNError("Token is missing or token is not correct. Please call login API to get a new token.")
    
    func_name = request.endpoint
    args = get_args()
    func = getattr(edc_data, func_name)

    if equipment: rv = func(fab, equipment=equipment, **args)   #沒有process
    else: rv = func(fab, process=process, **args)               #equipment在args

    return JSNResponse(rv)


def process_req_ui():
    check_and_log(ignore_token=True)

    if request.endpoint == 'get_main_menu':
        return render_template('default.html', description='Main Functions:',  action_url='/reset-config', action_name='Reset Config')

    if request.endpoint == 'reset_config':
        reset_config.reset_config()
        return render_template('default.html', message='Config refreshed!',  action_url='/home', action_name='Main Menu')





#region 讀寫cache
def find_cache():
    key = get_cache_key(request.full_path)
    redis = RedisDb.default()
    list = redis.get(key)
    if list is None: return None
    if list == '': return []
    return list.split(',')


def set_cache(list):
    try:
        key = get_cache_key(request.full_path)
        redis = RedisDb.default()
        expiry_hours=get_cache_expiry_hours()
        redis.set(key, ','.join(list), expiry_hours=expiry_hours)
    except Exception as err:
        logger = Logger.default()
        logger.error(f'"{err.args[0]}" on set_cache() in request_handler.py', exc_info=True)


#endregion


#region 取得查詢參數裡的cache選項

#優先採用request.headers裡的cacheType，若沒有或無法解析再使用系統的cache_type
def get_cache_type():
    if "cacheType" in request.headers: 
        try:
            return CacheType[request.headers["cacheType"]]
        except:
            pass

    #200514:查詢eqpt，只使用cache，不查詢資料庫，即使當月
    #200515:只限CNVR
    #elif request.endpoint == "get_eqpt_list" and request.view_args['process'] == 'CNVR':
    #200520:不限CNVR
    elif request.endpoint == "get_eqpt_list" and "month" in request.args:
        return CacheType.READONLY

    return RedisDb.cache_type()

#採用request.headers裡的expiryHours，若沒有或無法解析回傳None(會使用預設的 expiry_hours)，若小於等於0則cache不會timeout
def get_cache_expiry_hours():
    if "expiryHours" in request.headers: 
        try:
            return float(request.headers["expiryHours"])
        except:
            pass
    
    #ch200513:如果查詢的區間是by month且是當月，非eqpt清單，cache一天
    elif 'month' in request.args and request.args['month'] == datetime.today().strftime('%Y-%m') and request.endpoint != "get_eqpt_list":
        return 24.0

    return None

#endregion


#將查詢參數轉為一般Dictionary，並做參數轉換，與日期預處理
def get_args():
    dict = request.args.to_dict()

    #name mapping
    if "ownerCode" in dict: dict["owner_code"] = dict.pop("ownerCode")
    if "chamberCode" in dict: dict["chamber_code"] = dict.pop("chamberCode")
    if "withTypeCode" in dict: dict["with_type_code"] = dict.pop("withTypeCode")=="true"
    if "buildSqlOnly" in dict: dict["build_sql_only"] = dict.pop("buildSqlOnly")=="true"
    if "dataShapeWide" in dict: dict["data_shape_wide"] = dict.pop("dataShapeWide")=="true"
    if "prfxOpraEqpt" in dict: dict["prfx_opra_eqpt"] = dict.pop("prfxOpraEqpt")=="true"
    if "spcOperation" in dict: dict["spc_operation"] = dict.pop("spcOperation")
    if "measureType" in dict: dict["measure_type"] = int(dict.pop("measureType"))

    #posted data
    if request.method == 'POST':
        posted = request.get_json()
        if posted:
            if "EdcItems" in posted: dict["edc_items"] = posted["EdcItems"]
            if "SpcItems" in posted: dict["spc_items"] = posted["SpcItems"]


    #決定資料的日期區間start and end
    if "month" in dict:
        month = dict.pop("month") # eg. '2020-04'
        start_date = datetime.strptime(month, "%Y-%m") # eg. datetime.datetime(2020, 4, 1, 0, 0)
    elif "start" in dict:
        start = dict.pop("start")
        start_date = datetime.strptime(start, "%Y-%m-%d") if len(start) >= 8 else datetime.strptime(start, "%Y-%m")
    else:
        start_date = datetime.today()

    if "end" in dict:
        end = dict.pop("end")
        end_date = datetime.strptime(end, "%Y-%m-%d") if len(end) >= 8 else datetime.strptime(end, "%Y-%m")
        if end_date - start_date > timedelta(31):
            end_date = start_date + relativedelta(months = 1) - relativedelta(days = 1)
    else:
        end_date = start_date + relativedelta(months = 1) - relativedelta(days = 1)

    #ch200514:get_edc_spc_data要多給spc_end參數，spc資料可能落後edc二~三個月
    if "spc_operation" in dict and "operation" in dict:
        spc_end_date = start_date + relativedelta(months = 3)
        dict["spc_end"] = spc_end_date.strftime("%Y-%m-%d")

    dict["start"] = start_date.strftime("%Y-%m-%d")
    dict["end"] = end_date.strftime("%Y-%m-%d")

    return dict


