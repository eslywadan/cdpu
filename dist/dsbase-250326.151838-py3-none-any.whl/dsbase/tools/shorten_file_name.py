from typing import List, Dict, Union

# Find longest common prefix of a list of strings
def longest_common_prefix(strs: List[str]) -> str:
    if not strs:
        return ''
    shortest = min(strs, key=len)
    for i in range(len(shortest)):
        for other in strs:
            if other[i] != shortest[i]:
                return shortest[:i]
    return shortest

# Compact representation under max_len constraint
def compact_representation(values: List[str], max_len: int = 8) -> str:
    if not values:
        return ''
    
    # Single element case
    if len(values) == 1:
        return values[0][:max_len]  # Truncate if needed

    # Try full common prefix first
    common_prefix = longest_common_prefix(values)
    
    # Check if common prefix + '*' fits
    if common_prefix and len(common_prefix) + 1 <= max_len and len(common_prefix) >= 2:
        return common_prefix + '*'

    # If can't use common prefix, group by smaller prefixes (first 2 chars)
    prefix_size = 2  # Adjustable
    prefixes = sorted(set(v[:prefix_size] for v in values))
    
    result_parts = []
    total_len = 0
    for prefix in prefixes:
        part = prefix + '*'
        if total_len + len(part) <= max_len:
            result_parts.append(part)
            total_len += len(part)
        else:
            break  # Avoid overflow
    
    return ''.join(result_parts)

# Main function to process raw data and generate formatted string
def format_raw_data(
    raw_data: Dict[str, Union[str, List[str]]], 
    max_len: int = 8, 
    delimiter: str = ', '
) -> str:
    
    # Normalize all values to lists
    normalized_data = {k: (v if isinstance(v, list) else [v]) for k, v in raw_data.items()}
    
    # Sort keys by length of value list (ascending)
    sorted_items = sorted(normalized_data.items(), key=lambda item: len(item[1]))
    
    # Process each list to compact format
    formatted_elements = []
    for _, values in sorted_items:
        formatted = compact_representation(values, max_len)
        formatted_elements.append(formatted)
    
    # Join and return
    return delimiter.join(formatted_elements)

def example_usage():
	# -----------------------
	# ✅ Example usage
	raw_data = {
		'key1': ['abcd1234', 'abcd5678', 'abcd9999'],
		'key2': 'xyz12345',  # Single string case
		'key3': ['aaa0000'],
		'key4': ['longtext1', 'longtext2', 'longtext3', 'longtext4'],  # Longer list
        'key5': ['abc12', 'ab89', 'ac90'],  # expect 'ab*ac*'
    }

	result = format_raw_data(raw_data, max_len=8)
	print(result)  # Expected: aaa0000, xyz12345, abcd*, longtext*

def shorten_file_name(rawinfo:dict, max_lengh=30):
	"""

	"""
	result = format_raw_data(rawinfo, max_len=max_lengh, delimiter="_")
	return result