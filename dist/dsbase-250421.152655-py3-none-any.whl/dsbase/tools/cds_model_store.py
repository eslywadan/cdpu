from .clientdatastore import ClientDataStore
from .datastore import SelectCDS
from .config_loader import ConfigLoader
from io import BytesIO
from pandas import read_csv


"""
a sample record of one line of model store
{
    "My_class_model@2024-09-24T09.00.26.436Z:
    {
        "mdlpack":"ML_Service_Class"
        "session":"2024-09-24T09.00.26.436Z"
        "model_alias_name":"My_class_model",
        "model_alias_desc":"It is a sample class model",
        "model_release_version":"",  
        "dataset_name":"ML_Service_class_training",
        "dataset_version":"2024-06-07T04.00.30.166Z",
        "feature_list":"GE_AP1_ToRunTIM_EDC,GE_Acc_DI_Add_T_EDC,GE_RAK_3UP_AK_FL_EDC,GE_UL_ESD_Elec_EDC"
        "target_features":"Judge",
        "artifact": "Super_Stack_Model.pickle"
        "artifact_objid":"0c3355a5-0307-4296-8ace-63820f04b5e9",
        "validation_score":0.78,
        "testing_score":0.69,
        "evaluation":r2,
    }
}

Reconstruncted by CDS info
- a critical part of a model is it's artifact.
-  
"""

class ModelStore(SelectCDS):

    mdlartifactnames = ConfigLoader.config('mdlartifactnames')
    mdstore = None

    def __init__(self, cds: ClientDataStore):
        super().__init__(cds)
        self._reset_cds_file_meta()
        
    def _reset_cds_file_meta(self):
        self.cds.cdsfmeta.reload_cdsfmetadata()
        self.cdsfmeta = self.cds.cdsfmeta.cdsfilemetadata

    def get_distinct_models(self, model_filenames=None):
        if model_filenames == None: model_filenames = self.mdlartifactnames
        models = {}
        for filename in model_filenames:
            _models = self.get_distinct_singular_models(filename=filename)
            if type(_models) is dict: models.update(_models)
        return models

    def get_distinct_singular_models(self,step="06_models", filename="Super_Stack_Model.pickle"):
        models = self.get_mdlpacks_files(step=step, filename=filename)
        return models
    
    def get_done_from_trace(self,step="08_reporting", filename="trace.json", not_done_only=True):
        """
        [TODO] 1. Consider not overload innodrive if fetching too many files
               2. Trace result should be able to save into redis
        """
        traces = self.get_mdlpacks_files(step=step, filename=filename)
        if not not_done_only: return traces
        traces_not_done = {}
        for objid, item in traces.items():
            f = self.cds.get_file(objid)
            if not f.json()['done']:
                traces_not_done.update({objid: item})
        return traces_not_done
    
    def _model_cate(self, modelobjid):
        if modelobjid not in self.cdsfmeta: return 0
        elif 'model config info' in self.cdsfmeta[modelobjid]['retrain_model']['desc']: 
            if self.cdsfmeta[modelobjid]['retrain_model']['desc']['model config info']["mdlconfig"] == "retrain":
                return 1
            if self.cdsfmeta[modelobjid]['retrain_model']['desc']['model config info']["mdlconfig"] == "ml365":
                return 2

    def _get_nested_value(self, data:dict, criteria:list):

        if not criteria:
            return data
        
        current_key = criteria[0]
        if isinstance(data, dict) and current_key in data:
            return self._get_nested_value(data[current_key], criteria[1:])
        else:
            return None
        
    def _get_key_by_lower_kv(self, data:dict, search_key, search_value):

        _keys = []

        def recursive_search(data, key, value):
            if isinstance(data, dict):
                if key in data and data[key] == value:
                    return True
                for k,v in data.items():
                    if isinstance(v, dict) and recursive_search(v, key, value):
                        return True
            return False
        
        for objid, obj_info in data.items():
            if recursive_search(obj_info, search_key, search_value):
                _keys.append(objid)
        
        return _keys

    def get_models_info(self,category="all"):
        """
            category == "all" will list all models 
                     == "retrain" will list only retrain model
                     == "ml365" will list only ml365 model
        """
        distinct_mmodels = self.get_distinct_models()
        model_store = {}
        for modelobjid, _location in distinct_mmodels.items():
            mdl_cate_ = self._model_cate(modelobjid)
            if mdl_cate_ == 0:
                config_type = None
                config = None
                build  = None
                mdlpack = _location[1].split("/")[3]
                session = _location[1].split("/")[7]
                model_alias_name = mdlpack
                model_alias_desc = mdlpack
                model_release_version = "" 
                dataset_name = None
                dataset_version = None
                features_list = None
                target_feature = None
                jobid = None
                artifact = _location[0]
                artifact_objid = modelobjid
                validation_score =  None
                testing_score = None
                evaluate = None

            elif mdl_cate_ in [1, 2] : 
                config_type = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','desc','model config info',"mdlconfig"]) 
                config = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','desc','model config info'])
                build = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','desc','model build info'])
                mdlpack = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','desc','model config info', 'mdlpack'])
                session = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','desc','model config info', 'session'])
                model_alias_name = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','desc','model config info', 'model_alias_name'])
                model_alias_desc = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','desc','model config info', 'model_desc'])
                model_release_version = "",  
                dataset_name = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','desc','model config info', 'dataset_name'])
                dataset_version = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','desc','model config info', 'dataset_version'])
                features_list = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','desc','model config info', 'features_list'])
                target_feature = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','desc','model config info', 'target_feature'])
                jobid = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','desc','model config info', 'jobid'])
                artifact = _location[0]
                artifact_objid = modelobjid
                evaluate = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','desc','model build info', 'model_overview_evaluate'])
                if evaluate is not None:
                    validation_score = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','desc','model build info', 'evaluation', 'val', evaluate.lower()])
                    testing_score = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','desc','model build info', 'evaluation', 'test', evaluate.lower()])
                else:
                    validation_score = None
                    testing_score = None
            else :
                config_type = "misc"
                config = None
                build  = None
                # mdlpack = self.cdsfmeta[modelobjid]['retrain_model']['pipeline']
                mdlpack = self._get_nested_value(self.cdsfmeta[modelobjid],criteria=['retrain_model','pipeline'])
                session = self.cds.clientds.get_name_byid(self.cds.clientds.get_parent_byid(modelobjid))
                model_alias_name = mdlpack
                model_alias_desc = mdlpack
                model_release_version = "" 
                dataset_name = None
                dataset_version = None
                features_list = None
                target_feature = None
                jobid = None
                artifact = _location[0]
                artifact_objid = modelobjid
                validation_score =  None
                testing_score = None
                evaluate = None

            if category == "ml365" and config_type != "ml365": continue  
            if category == "retrain" and config_type != "retrain": continue
            if config_type == "ml365": model_key = f"{model_alias_name}@{session}"
            else: model_key = f"{mdlpack}@{session}"
            

            model_info = {
                model_key:
                    { "verbose": {
                        "filename":_location[0],
                        "location": _location[1],
                        "config": config,
                        "build": build
                        },
                    "express": {
                        "config": config_type,
                        "mdlpack": mdlpack,
                        "session": session,
                        "model_alias_name": model_alias_name,
                        "model_alias_desc": model_alias_desc,
                        "model_release_version":"",  
                        "dataset_name": dataset_name,
                        "dataset_version": dataset_version,
                        "feature_list": features_list,
                        "target_feature": target_feature,
                        "artifact": artifact,
                        "artifact_objid": artifact_objid,
                        "validation_score": validation_score,
                        "testing_score": testing_score,
                        "evaluation": evaluate,
                        "jobid": jobid
                        }
                }}
            
            if isinstance(artifact_objid, tuple):
                print(f"Debug 1: Type of artifcat_objid:{type(artifact_objid)}")
                print(f"Type of modelobjid: {type(modelobjid)} / modelobjid: {modelobjid}")

            model_store.update(model_info)
        self.mdstore = model_store
        return model_store
    
    def get_artifact_objid(self, mdl_name, version):
        if self.mdstore is None: self.get_models_info()
        info_key = f'{mdl_name}@{version}' 
        if info_key in self.mdstore.keys():
            artifact_objid =  self._get_nested_value(self.mdstore[info_key], criteria=['express','artifact_objid'])
            return artifact_objid
        else: return f"Given {mdl_name}/{version} not found"

    def get_metrics_view(self, artifact_objid):
        if artifact_objid in self.cdsfmeta.keys():
            metrics_view = self._get_nested_value(self.cdsfmeta[artifact_objid],
                                                   criteria=['retrain_model','desc','model build info', 'evaluation', 'metrics_view'])
            if metrics_view is None: # Case when cdsfmeta has not the data, try to get it from file
                flist = self.get_cds_evaluation_file(artifact_objid)
                for objid in flist.keys():
                    evaluation = self._cds_load_json(objid)
                metrics_view = self._get_nested_value(evaluation, criteria=['metrics_view'])
            return metrics_view
        
    def get_metrics_view_by_mdl_version(self, mdl_name, version):
        objid = self.get_artifact_objid(mdl_name=mdl_name, version= version)
        if objid in self.cdsfmeta.keys():
            return self.get_metrics_view(objid) 

    def get_cds_evaluation_file(self, artifact_objid):
        mdlpack = self._get_nested_value(self.cdsfmeta[artifact_objid], criteria=['retrain_model','desc','model config info','mdlpack'])
        version = self._get_nested_value(self.cdsfmeta[artifact_objid], criteria=['retrain_model','desc','model config info','session'])
        flist = self.get_files(**{"mdlpack":mdlpack,"version":version,"evaluation":"evaluation.json"})
        return flist
    
    def get_leaderboard(self, artifact_objid):
            flist = self.get_cds_leaderboard_file(artifact_objid)
            for objid in flist.keys():
                leaderboard_ = self._cds_load_csv(objid)
            leaderboard = leaderboard_
            return leaderboard
        
    def get_leaderboard_by_mdl_version(self, mdl_name, version):
        objid = self.get_artifact_objid(mdl_name=mdl_name, version= version)
        if objid in self.cdsfmeta.keys():
            return self.get_leaderboard(objid) 
    
    def get_cds_leaderboard_file(self, artifact_objid):
        mdlpack = self._get_nested_value(self.cdsfmeta[artifact_objid], criteria=['retrain_model','desc','model config info','mdlpack'])
        version = self._get_nested_value(self.cdsfmeta[artifact_objid], criteria=['retrain_model','desc','model config info','session'])
        flist = self.get_files(**{"mdlpack":mdlpack,"version":version,"leaderboard":"leaderboard.csv"})
        return flist    
    
    def _cds_load_json(self, objid):
        """
        given objid is the object id of cds@innodrive,
        works on give objid and read the file to return a dic
        """
        resp = self.cds.get_file(objid)
        if resp.status_code == 200:
            return resp.json()
        else: return None

    def _cds_load_csv(self, objid):
        """
        given objid is the object id of cds@innodrive,
        works on given objid and than reading the file to return a dataframe
        """
        resp = self.cds.get_file(objid)
        if resp.status_code == 200:
            df = read_csv(BytesIO(resp.content))
            return df
        else: return None