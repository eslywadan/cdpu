from dsbase.tools.datastore import SelectCDS, DataStore
from pathlib import Path
import os
from datetime import datetime

try: 
    currentfilepath = os.path.abspath(__file__)
except:
    currentfilepath = os.path.join(os.getcwd(),"dsbase\\tests\\test_datastore.py")

print(f"current file path:{currentfilepath}")
test_data_path = os.path.join(Path(currentfilepath).parent.parent,'test_data')
print(f"test data path {test_data_path}")

def test_data_store_upload():
    """
    Testing Abstract: The purpose is going to upload a testing file from the local path 
    resides at 'test_data' subfolder underr dsbase 
    testing script: 
    Have a test client id "test_data_store"
    Have a DataStore instance ds
    Have a SelectCDS instance scds
    Make sure the existence of the 'data_store/upload' path
    test uploading a dataset name 'ML_Service_training' with 'init' version
    """
    clientid = "test_data_store"
    ds = DataStore(clientid=clientid)
    # data_store folder should not exist, this SelectCDS should return []
    scds = SelectCDS(ds.cds)
    assert scds.get_folders(**{"fldername1":"data_store","fldername2":"upload"}) != {}
    # test upload data
    dataset = "ML_Service_training"
    version = "init"
    filename = "ML_Service_training.csv"
    s_datasetpath = os.path.join(test_data_path,dataset, version)
    l_datasetpath = os.path.join(test_data_path,"local")
    assert os.path.exists(s_datasetpath)
    inkwargs = {"meta_file":"meta_file.json", "meta_data":{"data_set": "ML_Service_Training","columns_num": 33,"rows_num": 239, "create_time":"20240820133605"}}
    ds.putdata(dataset=dataset, version=version, sourcedatasetpath=s_datasetpath, sourcefilename=filename, **inkwargs)

    version = "20240820133835"
    s_datasetpath = os.path.join(test_data_path,dataset, version)
    assert os.path.exists(s_datasetpath)
    inkwargs = {"meta_file":"meta_file.json","change_log":"change_file.json", "meta_data":{"data_set": "ML_Service_Training","columns_num": 33,"rows_num": 237, "create_time":"20240820133835"}}
    ds.putdata(dataset=dataset, version=version,sourcedatasetpath=s_datasetpath, sourcefilename=filename, **inkwargs)

    version = "20240820134825"
    s_datasetpath = os.path.join(test_data_path,dataset, version)
    assert os.path.exists(s_datasetpath)
    inkwargs = {"meta_file":"meta_file.json","change_log":"change_file.json", "meta_data":{"data_set": "ML_Service_Training","columns_num": 33,"rows_num": 234, "create_time":"0240820134825"}}
    ds.putdata(dataset=dataset, version=version,sourcedatasetpath=s_datasetpath, sourcefilename=filename, **inkwargs)
    msg = ds.get_objids_path_by_nameversion(dataset="ML_Service_training", version="init")
    msg = ds.get_objids_path_by_nameversion(dataset="ML_Service_training")
    msg = ds.get_data_by_nameversion(local_file_path=l_datasetpath,dataset="ML_Service_training", version="init")
    
    # final test to del the CDS for clientid
    ds.cds.clientds.del_folder((ds.cds._folder_id))

def test_data_store_upload_with_projectid_featureid():
    """
    Testing Abstract: The purpose is going to upload a testing file from the local path 
    resides at 'test_data' subfolder underr dsbase
    testing script: 
    Have a test client id "test_data_store"
    Have a DataStore instance ds
    Have a SelectCDS instance scds
    Make sure the existence of the 'data_store/upload' path
    test uploading a dataset name 'ML_Service_training' with 'init' version
    and update the meta with projectid (ex:'carux') and featureid (ex: 'F4,F5,F6')
    """
    clientid = "apds"
    ds = DataStore(clientid=clientid)
    # data_store folder should not exist, this SelectCDS should return []
    scds = SelectCDS(ds.cds)
    assert scds.get_folders(**{"fldername1":"data_store","fldername2":"upload"}) != {}
    # test upload data
    dataset = "apds_sample_data"
    version = datetime.strftime(datetime.now(), '%Y%m%d%H%M%S')
    filename = "apds_sample_data.csv"
    s_datasetpath = os.path.join(test_data_path,dataset, 'init')
    l_datasetpath = os.path.join(test_data_path,"local")
    assert os.path.exists(s_datasetpath)
    inkwargs = {"meta_file":"apds_sample_data_meta.json", 
                "meta_data":{"data_set": dataset,"columns_num": None,"rows_num": None, "create_time":version,
                             "ml365_project": 'carux',"ml365_features": "F4,F5,F6"}}
    ds.putdata(dataset=dataset, version=version, sourcedatasetpath=s_datasetpath, sourcefilename=filename, **inkwargs)


def test_data_store_dataservice():
    """
    Testing Abstract: A collaborated front end such as apds has requested to fetch data from its api and then store the dataset at cds.
        The testing steps start with ndeq.ttlsap.sa_carux_apds by using the CarUxApi, and eloborats the detail of its save_clientdatastore 
        function.  
    Testind Assumption:
    1. Given source file path, file name
    2. versioning with init
    3. tag the feature id for the responding data objid in the meta_data field of its cds_file_meta_$clienid.json
    4. save the conditions data as the meta file 
    5. class DataStore has self.upload_data_store_path and self.dataservice_data_store_path, the case is expected top 
    store the data in the self.dataservice_data_store_path

    Testing Criteria:
    1. The sample condition and sample data are extacted 
    2. The target data is stored correctly at the datastore-dataservice path in cds
    3. The full path contains the data set name and the version
    4. the condistion data is saved as the meta_file
    5. the feature ids info is taged in the cds_file_meta_$clientid.json
    """
    from ndeq.ttlsap.sa_carux_apds import CarUxApi
    clientid = "test_data_store"
    caruxapi = CarUxApi(clientId=clientid)

    caruxapi.get_data_by_sample_condition()
    kwargs = {"ProjectId":"carux","FeatureId":"F4,F5,F6"}
    caruxapi.save_clientdatastore(**kwargs)
    # confidtion_file will be upladed as the "meta_file"
    ds = DataStore(clientid=clientid)
    # data_store folder should not exist, this SelectCDS should return []
    scds = SelectCDS(ds.cds)
    assert scds.get_folders(**{"fldername1":"data_store","fldername2":"dataservice"}) != {}

def test_mdlpacks_repo():
    ds = DataStore()
    sds = SelectCDS(ds.cds)
    assert sds.get_endpoint_objid(repository="/eng/mdlpacks") is not None
    assert sds.mdlpackrepo == "/eng/mdlpacks"
    # arbitary repository and criteria
    repository = "/eng/mdlpacks/Graffiti"
    kwargs = {"filename":"X_test.pq"}
    sds.get_files(repository,**kwargs)
    sds._get_fileids_by_kw(repository,**kwargs)
    sds.get_mdlpacks_files(sessionid="2024-05-14T05.15.10.340Z", step="03_primary", filename="X_test.pq")

def test_data_upload_repo_exists():
    ds = DataStore()
    sds = SelectCDS(ds.cds)
    assert sds.get_endpoint_objid(repository="/eng/data_store/upload") is not None

def test_contexure_data_list():
    clientid = 'apds'
    ds = DataStore(clientid)
    contexture1= {"featureId":"F4"}
    r1 = ds._contexture_data_list(contexture=contexture1)
    assert len(r1) > 0 
    contexture2= {"featureId":"F1"}
    r2 = ds._contexture_data_list(contexture=contexture2)
    assert len(r2) == 0 
    r3 = ds._contexture_data_list()
    assert r1 == r3
