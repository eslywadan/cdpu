import sys

path = sys.path
print(path)