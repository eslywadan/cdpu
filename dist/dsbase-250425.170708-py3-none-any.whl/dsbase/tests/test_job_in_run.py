import requests
from dsbase.tools.redis_db import RedisDb
from datetime import datetime
import json

redis = RedisDb.default()

host = 'http://10.53.200.183'
port = 34675


#host = 'http://10.56.133.132'
#port = 8080
get_apikey_1 = f"{host}:{port}/ds/utility/apikey?clientId=eng&password=eng"
resp_apikey = requests.get(url=get_apikey_1)
apikey = resp_apikey.json()

url_class = f"{host}:{port}/ds/ml/class"

headers = {"accept":"application/json",
            "apikey":apikey, # replace by testing api key
            "Content-Type":"application/json"}

payload_class = {"ml":"ml365",  
            "mdlname":"ml365_md_exp_class_test",  # replace payload value if needed
            "mdldesc":"It is a ml365 model exploration test for classification task", 
            "train_data_objid":"6b5cbdad-f7e3-4376-a658-2951d4c87693",
            "train_data_features":"GE_AP1_ToRunTIM_EDC,GE_Acc_DI_Add_T_EDC,GE_RAK_3UP_AK_FL_EDC,GE_UL_ESD_Elec_EDC",
            "train_data_target":"Judge"}

normal_resp_class = requests.post(url_class, json = payload_class, headers=headers)
assert normal_resp_class.json()['message']

jobid = normal_resp_class.json()['jobid']

from dsbase.tools.job_store import ClientJobs, redis
from time import sleep
clientid = 'eng'

clientjobs = ClientJobs(clientid=clientid)

assert clientjobs.clientid == clientid

assert clientjobs.jobtype == 'ml365_'

## test* the maxtimelag case when the recall time is under maxtimelag
pat = "*"
all_jobs_at_start_t1 = clientjobs.get_pat_jobs_at_start(pat)
all_jobs_at_start_t2 = clientjobs.get_pat_jobs_at_start(pat)
assert all_jobs_at_start_t2 == all_jobs_at_start_t1

pat = "eng"
all_jobs_at_start_t3 = clientjobs.get_pat_jobs_at_start(pat)
all_jobs_at_start_t4 = clientjobs.get_pat_jobs_at_start(pat)
assert all_jobs_at_start_t2 == all_jobs_at_start_t1

assert redis.get(f"{jobid}@start") is not None

alljobsatend = clientjobs.get_pat_jobs_at_end()
alljobsend = clientjobs.get_pat_jobs_at_end(pat='*')
alljobsprocess = clientjobs.get_pat_jobs_at_proc(pat='*')
assert jobid not in alljobsatend



jobidendinfo = redis.get(f"{jobid}@end")
sleep(1)

assert redis.get(f"{jobid}@proc") is not None

print(f"jobidendinfo: {jobidendinfo}")

assert redis.get(f"{jobid}@end") is None
print(f"{jobid} has not end status at {datetime.now().strftime('%Y/%m/%d %H:%M:%S')}")
alljobsend = clientjobs.get_pat_jobs_at_end()

if jobid in alljobsend: 
    print(f"{jobid} has end status at {datetime.now().strftime('%Y/%m/%d %H:%M:%S')}")
    endinfo = redis.get(f"{jobid}@end")
    while endinfo is None:
        sleep(3)
        endinfo = redis.get(f"{jobid}@end")
    endinfo = json.loads(endinfo)
    print(f"{jobid}@end / {endinfo}")
    if "endtime" in endinfo: print(f"job end time {endinfo['endtime']}")


alljobsprocess = clientjobs.get_pat_jobs_at_proc()
assert jobid in alljobsprocess
assert jobid in clientjobs._keys_substract(alljobsprocess, alljobsend)

alljobsinrun= clientjobs.get_all_jobs_in_run()
jobsinproc = clientjobs.get_pat_jobs_in_proc()


assert jobid in jobsinproc

endinfo = redis.get(f"{jobid}@end")

while endinfo is None:
    sleep(3)
    endinfo = redis.get(f"{jobid}@end")

jobsinproc = clientjobs.get_pat_jobs_in_proc()

assert jobid not in jobsinproc 
