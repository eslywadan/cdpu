import unittest
from flask import Flask
from dsbase.tools.utility import utility

class UtilityApiTestCase(unittest.TestCase):
    def setUp(self):
        self.app = Flask(__name__)
        self.app.register_blueprint(utility)
        self.client = self.app.test_client()
        self.app.testing = True

    def test_post_apikey(self):
        response = self.client.post('/apikey/', json={
            'clientId': 'eng',
            'password': 'eng'
        })
        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        print(data)
        #self.assertIn('apikey', data)


def test_suite():
    print("runnig test suite")
    # Create a test suite
    suite = unittest.TestSuite()

    # Add the test case
    suite.addTest(UtilityApiTestCase('test_post_apikey'))

    # Create a test runner that will run the test suite
    runner = unittest.TextTestRunner()

    # Run the test suite
    runner.run(suite)

if __name__ == '__main__':
    unittest.main()
