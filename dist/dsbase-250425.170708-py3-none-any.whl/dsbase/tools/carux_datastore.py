from dsbase.tools.datastore import DataStore
from collections import defaultdict

class CaruxDataStore(DataStore):

    def __init__(self, clientid="eng"):
        super().__init__(clientid)

    def get_data_list(self,sourceType=['upload','dataservice'],contexture={"featureId":None},headerOnly=False):
        return self._rearrange_with_department(sourceType,contexture,headerOnly)
    
    def _rearrange_with_department(self,sourceType=['upload','dataservice'],contexture={"featureId":None},headerOnly=False):
        dl = self._contexture_data_list(sourceType,contexture,headerOnly)
        if dl:
            rearrangedatastore = defaultdict(dict)
            for dle, dleinfo in dl.items():
                newKey = f"None@{dleinfo['datasetObj']}"
                if "functionType" in dleinfo.keys():
                    if dleinfo["functionType"] is not None: newKey = f"{dleinfo['functionType']}@{dleinfo['datasetObj']}"
                    
                dleinfo_ = self._fix_dleinfo(dleinfo) 
                rearrangedatastore[newKey] = {
                        'path': dle,
                        'datasetName': dleinfo_["datasetName"],
                        'datasetObj': dleinfo_["datasetObj"],
                        'datasetObjName': dleinfo_['datasetObjName'],
                        'version': dleinfo_['version'],
                        'sourceType': dleinfo_['sourceType'],
                        'createTime':dleinfo_['createTime'],
                        'ml365_project': dleinfo_['ml365_project'],
                        'ml365_features': dleinfo_['ml365_features'],
                        'columns_num': dleinfo_['columns_num'],
                        'rows_num': dleinfo_['rows_num'],
                        'functionType': dleinfo_['functionType']
                    }
            return rearrangedatastore
        else: return    

    def _fix_dleinfo(self,_dleinfo):
        """it is a data fixing utility for those data with legacy issues
        caused by change or rules are not turning down.
        it should be removed when no more needs.
        (1) keys not set for legacy data-> reset the key
        (2) 'ml365_features' -> alter the ['F4, F6'] to ['F6']
        """

        dleinfo_ = _dleinfo
        if 'createTime' not in _dleinfo.keys(): dleinfo_["createTime"] = None
        if 'ml365_project' not in _dleinfo.keys(): dleinfo_["ml365_project"] = None
        if 'ml365_features' not in _dleinfo.keys(): dleinfo_["ml365_features"] = None
        elif _dleinfo['ml365_features'] == ["F4","F6"]: dleinfo_["ml365_features"] = ["F6"] # Not to show on "F4"
        if 'columns_num' not in _dleinfo.keys(): dleinfo_["columns_num"] = None
        if 'rows_num' not in _dleinfo.keys(): dleinfo_["rows_num"] = None
        if 'functionType' not in _dleinfo.keys(): dleinfo_["functionType"] = None
        return dleinfo_
