from dsbase.tools.cds_model_store import ModelStore
from dsbase.tools.clientdatastore import ClientDataStore
from dsbase.tools.logger import Logger
from io import BytesIO
from pandas import read_parquet, DataFrame, read_json
import os

class ModelPredict(ModelStore):
    """
    attributes:
    1. x_test_training : X testing file name during training (static "X_test.pq")
    2. y_test_training : y testing file name  during training (static "y_test.pq")
    3. predict_test_file_name : predict test file name, used for storing predict test records. (static: "predict_test.json")

    4. predict_test_folder : endpoint objid to do upload
    """
    x_test_ = "X_test.pq"
    y_test_ = "y_test.pq"
    predict_test_output_y_name = "predict_test_y.json"
    predict_test_file_name = "predict_test.json"
    predict_test_input_folder = "05_model_input"
    predict_test_file_loc = "07_model_output"
    predict_test_file = {}

    def __init__(self, cds:ClientDataStore, mdlname, mdlversion, create_template=False):
        """
        use mdlname & mdlversion to locate model obj
        """
        super().__init__(cds)
        self.get_models_info()
        self.reset_model_info(mdlname, mdlversion)
        if self.tmdlname != None:
            print(f"tmdlname : {self.tmdlname} tmdlversion {self.tmdlversion}")
            self._set_predict_test_folder()
            self._set_predict_test_file()
            if create_template or (self.predict_test_file_objid is None):
                self._create_ifnotexists_cds_predict_test_file()
                self.cds.clientds.set_items_all_by_tree(objid=self.cds._folder_id)
                self._set_predict_test_folder()
                self._set_predict_test_file()
            else: Logger.log(f"ModelPredict init : {self.predict_test_file_objid} ")
        else: Logger.log(f"ModelPredict init : Given mode name  {mdlname} and model version {mdlversion} not found in mdstore")
    
    def get_predict_test_file_objid(self):
        return self.predict_test_file_objid

    def get_cds_predict_test_xlist(self):
        flist = self.get_files(**{"mdlpack":self.tmdlpack,"predict_test_input_folder":self.predict_test_input_folder,
                          "predict_test":self.predict_test_file_name, "version":self.tmdlversion})
        return flist
        
    def get_cds_predict_test_output_list(self):
        flist = self.get_files(**{"mdlpack":self.tmdlpack,"predict_test_file_loc":self.predict_test_file_loc,
                          "predict_test_output_y":self.predict_test_output_y_name , "version":self.tmdlversion})
        return flist    

    def upload_cds_predict_test_x_data(self, **kwargs):
        """
        {s} will be uploaded into the designated location
        The designated location is generally located at 05_model_input/predict_test.json
        """
        fpath = kwargs['sfilepath']
        sfilename = kwargs['sfilename']

        resp = self.cds._upload_file(sfilepath=fpath,sfilename=sfilename,
                        tfilename=sfilename, endpointid=self.predict_test_upload_folder_endpoint)
        return resp

    def upload_cds_predict_test_output_data(self, **kwargs):
        """
        {s} will be uploaded into the designated location
        The designated location is generally located at 07_model_output/predict_test.json
        with verison
        """
        fpath = kwargs['sfilepath']
        sfilename = kwargs['sfilename']

        resp = self.cds._upload_file(sfilepath=fpath,sfilename=sfilename,
                        tfilename=sfilename, endpointid=self.predict_test_output_folder_endpoint)
        return resp
    
    def upload_cds_predict_test_data(self, **kwargs):
        """
        {s} will be uploaded into the designated location
        The designated location is generally located at 07_model_output/predict_test.json
        without version
        """
        fpath = kwargs['sfilepath']
        sfilename = kwargs['sfilename']
        tfilename = f"{self.clienid}_{self.tmdlpack}_predict_test.json"
        resp = self.cds._upload_file(sfilepath=fpath,sfilename=sfilename,
                        tfilename=tfilename, endpointid=self.predict_test_data_path_endpoint)
        return resp

    def reset_model_info(self, mdlname, mdlversion):
        if f"{mdlname}@{mdlversion}" in self.mdstore.keys():
              self.tmdlname = mdlname
              self.tmdlversion = mdlversion
              self.tmdlkey = f"{mdlname}@{mdlversion}"
              self.tmdlinfo = self.mdstore[self.tmdlkey]
              self.tmdlpack = self._get_nested_value(self.tmdlinfo, criteria=['verbose','config','mdlpack'])
              self.artifact_loc = self._get_nested_value(self.tmdlinfo, criteria=['verbose','location'])
              self.predict_test_upload_folder = "/".join(self.artifact_loc.split("/")[2:5]+[self.predict_test_input_folder,self.predict_test_file_name, self.tmdlversion])
              self.data_root_ = "/".join(self.artifact_loc.split("/")[2:5]+[self.predict_test_file_loc,self.predict_test_output_y_name, self.tmdlversion])
              self.predict_test_data_path = "/".join(self.artifact_loc.split("/")[2:5]+[self.predict_test_file_loc,self.predict_test_file_name,self.tmdlversion])
              self.predict_test_file_name = f"{self.clienid}_{self.tmdlpack}_{self.predict_test_file_name}"
              self.local_template_xfile_name = f"predict_test_template_x_{self.tmdlversion}.json"
        else: 
              self.tmdlname = None
              self.tmdlversion = None
              self.tmdlkey = None
              self.tmdlinfo = None
              print( f"Given mode name  {mdlname} and model version {mdlversion} not found in mdstore")
        
    def _create_ifnotexists_cds_predict_test_file(self):
        """
          1. locate the endpoint of upload file location & output file location
        """
        if self.check_existence_of_predict_test_file(resetmeta=False): return
        self._gen_predict_test_template()        
        assert self.check_existence_of_predict_test_file(resetmeta=True)

    def _set_predict_test_folder(self):
        resp = self.cds.clientds.path_maker(self.cds._folder_id, filepath=self.predict_test_upload_folder)
        if resp["status"] == "OK": 
            self.predict_test_upload_folder_endpoint = resp["endpoint"]
        else: Logger.log(f"Model Predict _set_predict_test_folder create filepath {self.predict_test_upload_folder} at {self.cds._folder_id} fail with resp {resp}")
        
        resp  = self.cds.clientds.path_maker(self.cds._folder_id, filepath=self.data_root_)
        if resp["status"] == "OK": 
            self.predict_test_output_folder_endpoint = resp["endpoint"]        
        else: Logger.log(f"Model Predict _set_predict_test_folder create filepath {self.data_root_} at {self.cds._folder_id} fail with resp {resp}")

        resp  = self.cds.clientds.path_maker(self.cds._folder_id, filepath=self.predict_test_data_path, resetinfo=True)
        if resp["status"] == "OK": 
            self.predict_test_data_path_endpoint = resp["endpoint"]
        else: Logger.log(f"Model Predict _set_predict_test_folder create filepath {self.predict_test_data_path} at {self.cds._folder_id} fail with resp {resp}")

    def _set_predict_test_file(self):
        """
        will set the self.predict_test_file_objid = None then find the existence of the predict test file.
        If existed, the object id will be assigned. 
        """
        self.predict_test_file_objid = None
        self.predict_test_file = self.get_files(**{"mdlpack":self.tmdlpack,"predict_test_file_loc":self.predict_test_file_loc,"predict_test":self.predict_test_file_name, "version":self.tmdlversion})
        for objid in self.predict_test_file.keys():
            self.predict_test_file_objid = objid
        # assert self.predict_test_file_objid is not None

    def check_existence_of_predict_test_file(self, resetmeta=True):
        if resetmeta: self.cds.clientds.set_client_items_all(self.clienid)
        _file = self.get_files(**{"mdlpack":self.tmdlpack,"predict_test_file_loc":self.predict_test_file_loc,"predict_test":self.predict_test_file_name, "version":self.tmdlversion})
        if _file.__len__() == 0:
            self.predict_test_file = {} 
            return False
        else: 
            self.predict_test_file = _file
            return True

    def _gen_predict_test_template(self):
        """
        1. locate the file of X_test.pq and Y_test.pq
        2. Read X_test.pq and Y_test.pq and insert to the template
        3. Append required fields to form the tempalte
        """
        if not os.path.exists('temp'): os.mkdir('temp')
        temp_folder = os.path.join(os.getcwd(), "temp")
        resp_x = self.get_files(**{"mdlpack":self.tmdlpack,"x_test_":self.x_test_, "version":self.tmdlversion})
        for objid in resp_x.keys():
            df_x = self._cds_load_pq(objid)

        resp_y = self.get_files(**{"mdlpack":self.tmdlpack,"y_test_":self.y_test_, "version":self.tmdlversion})
        for objid in resp_y.keys():
            df_y = self._cds_load_pq(objid)
        
        
        local_template_xfile_path = os.path.join(temp_folder, self.local_template_xfile_name)
        df_x[:10].to_json(local_template_xfile_path)
        resp_x = self.upload_cds_predict_test_x_data(**{"sfilepath":local_template_xfile_path ,"sfilename":self.local_template_xfile_name})

        self.local_template_outputfile_name = f"predict_test_template_y_{self.tmdlversion}.json"
        local_template_outputfile_path = os.path.join(temp_folder, self.local_template_outputfile_name)
        _df = DataFrame({**df_x.iloc[:10], **df_y.iloc[:10]})
        _df.to_json(local_template_outputfile_path)
        resp_y = self.upload_cds_predict_test_output_data(**{"sfilepath":local_template_outputfile_path ,"sfilename":self.local_template_outputfile_name})
            
        _df0 = DataFrame({'version':{'0':self.tmdlversion},'X_test':{'0':resp_x.json()[0]["id"]}, 'y_test':{'0':resp_y.json()[0]["id"]}, 'score' : {'0':None}, 'status': {'0':None}, 'create_time': {'0':None}})

        self.local_template_file_name = f"{self.clienid}_{self.tmdlpack}_predict_test.json"
        local_tempate_file_path = os.path.join(temp_folder, self.local_template_file_name)
        _df0.to_json(local_tempate_file_path)
        resp_r = self.upload_cds_predict_test_data(**{"sfilepath":local_tempate_file_path ,"sfilename":self.local_template_file_name})
        self.template_input_content = _df0
        self._predict_test_summary_objid = resp_r.json()[0]['id']

    def _cds_load_pq(self, objid):
        """
        given objid is the object id of cds@innodrive,
        works on give objid and read the file as pandas data frame, take position 0 
        record, convert it into json and return
        """
        resp = self.cds.get_file(objid)
        if resp.status_code == 200:
             df = read_parquet(BytesIO(resp.content))
             return df
        else: return None

    def _cds_load_json(self, objid):
        """
        given objid is the object id of cds@innodrive,
        works on give objid and read the file as pandas data frame, take position 0 
        record, convert it into json and return
        """
        resp = self.cds.get_file(objid)
        if resp.status_code == 200:
            df = DataFrame(resp.json())
            return df
        else: return None

    def get_x_tempalte(self):
        resp_x_template = self.get_files(**{"mdlpack":self.tmdlpack,"x_test_template":self.local_template_xfile_name, "version":self.tmdlversion})
        for objid in resp_x_template.keys():
            df_x_template = self._cds_load_json(objid)
        
        return df_x_template
        

