from dsbase.tools.clientdatastore import ClientDataStore
import hashlib
from dsbase.tools.logger import Logger
import json
import io

class CDSHouseKeep(ClientDataStore):

    def __init__(self,**kwargs):
        super().__init__(**kwargs)
        

    def hash_file_sha256_local_file(filepath):
        "calculate the SHA-256 hash if a file"
        sha256_hash = hashlib.sha256()
        with open(filepath, 'rb') as file:
            for chunk in iter(lambda: file.read(4096), b""):
                sha256_hash.update(chunk)
        return sha256_hash.hexdigest()
    
    def hash_file_sha256_remote_file(self, objid):
        "calculate the SHA-256 hash for given remtote objid"
        sha256_hash = hashlib.sha256()
        rf = self.get_file(objid, auto_redirect=False)
        if rf.status_code == 200:
            vr = self.verify_delegate_rep_obj(rf.content)
            if vr["delegate"] : return vr["hash_key"]
            for chunk in rf.iter_content(chunk_size=4096):
                sha256_hash.update(chunk)
        return sha256_hash.hexdigest()

    def get_identical_files(self, force_renew=False, **kwargs):
        """
        identical file is grouped by its content's hash value as the key and the set of objids for the same hash value
        """
        if force_renew : 
            self.identical_files = self._find_identical_files()
            self.upload_identical_files_dict()
            return self.identical_files
        
        ffileid = self.clientds.get_id_byname_and_parentid('identical_files.json',self._folder_id)
        if ffileid['status'] == 'Not found': 
            fffileid = self.clientds.get_id_byname_and_parentid('identical_files.json',self._folder_id, resetinfo=True)
            if fffileid['status'] == 'Not foud': 
                self.identical_files = self._find_identical_files()
                self.upload_identical_files_dict()
                return self.identical_files
            else: fileid = fffileid['objid']
        else: fileid = ffileid['objid']
        gf = self.get_file(fileid)
        if gf.status_code == 200: self.identical_files = gf.json()
        else: self.identical_files = None

    def _find_identical_files(self):
        """
        steps for discriminate identical files
        (1) the same client id
        (2) the same bytes size (high possibility the same)
        (3) the same hash value (validation step)
        Bytes size 3456863 has multiple files {'d6617b7b-9276-4c57-a8c7-585a94632377', 'a9b0b8cf-e728-4a5c-990b-afb807553f66', '589afb64-c610-4ec4-a4cc-87d80851ea2d'}
        The same size files may differ in content, thus it may reduce the numeber of identical files after hash validation
        """
        self.group_objids_by_size()
        file_hash_set = {}
        identical_files = {}
        for bytes_set in self.bytes_set:
            bytes = bytes_set[0]
            ids = bytes_set[1]
            if len(ids) > 1: 
                Logger.log(f"Bytes size {bytes} has multiple files {ids} ")
                for objid in ids:
                    objid_hash = self.hash_file_sha256_remote_file(objid)
                    if objid_hash not in file_hash_set: file_hash_set[objid_hash] = []
                    file_hash_set[objid_hash].append(objid)
        
        self.file_hash_set = file_hash_set
        # Remove the hash_set that has only one objecid, the remaining hash_set will contain multiple objectid for each hash key
        for hash_key, objids in self.file_hash_set.items():
            if len(objids) >1 : identical_files[hash_key] = objids

        return identical_files
    
    def upload_identical_files_dict(self):
        with open("identical_files.json", 'w') as f:
            json.dump(self.identical_files, f)

        upf = self._upload_file('identical_files.json', 'identical_files.json', 'identical_files.json', self._folder_id )
    
    def list_file_type_objs(self):
        objids = [objid for objid, type in self.clientds.idtype.items() if type == "F"]
        self.file_type_objs = objids
        return objids
    
    def list_same_size_objs(self, _bytes:int):
        objids = [objid for objid, byyes in self.clientds.idbyte.items() if bytes == _bytes]
        return objids

    def list_same_name_objs(self, _name:str):
        objids = [objid for objid, name in self.clientds.idname.items() if name == _name]
        return objids    
    
    def group_objids_by_size(self):
        bytes_set = {}
        for objid, bytes in self.clientds.idbyte.items():
            if bytes not in bytes_set:
                bytes_set[bytes] = set()
            bytes_set[bytes].add(objid)
        del bytes_set[0]
        bytes_set = sorted(bytes_set.items(), key=lambda item: (item[0], len(item[1])))
        self.bytes_set = bytes_set
        return bytes_set 
    
    def file_info(self,fileid):
        return self.cdsfmeta.file_info(fileid)
    
    def delegate_content_to_rep_objid(self,hash_key):
        """
        The set of idential files has its hash_key of the file content and the selected representative object id reserved for keeping the content.
        """
        replace_content = {}
        if hash_key in self.identical_files.keys():
            rep_objid  = list(self.identical_files[hash_key])[0]
            replace_content["rep_objid"] = rep_objid
            replace_content["hash_key"] = hash_key
            replace_content = str(replace_content).encode('utf-8')
            magic_bytes = self.magic_bytes_delegate_content_to_rep_obj
            sfile = f"{hash_key}.txt"
            with open(sfile, 'wb') as file:
                file.write(magic_bytes+replace_content)

        else: return {"status_code":401, "message":f"provided hash_key {hash_key} is not in the identical files set"}

        for objid in self.identical_files[hash_key]:
            if objid == rep_objid: pass
            if self.verify_delegate_rep_obj_byid(objid): pass
            else:
                self._replace_file_content_by_rep_objid(replaced_objid=objid, sfile=sfile)
    
    def _replace_file_content_by_rep_objid(self, replaced_objid, sfile):
        file_info = self.file_info(replaced_objid)
        if file_info.status_code ==  200: 
            endpoint = file_info.json()[0]['parenT_ID']
            tfilename = file_info.json()[0]['filE_NAME']
        
        return self._upload_file(sfilepath=sfile, sfilename=sfile, tfilename=tfilename, endpointid=endpoint)

