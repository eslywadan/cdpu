import json
import os
from pathlib import Path

class ConfigLoader:
    """
    configs has (1) config used for general purpose and 
                (2) config_test used for testing purpose
    config path could be an assigned path or read the Axim from the project.py            
    """

    _config_all = {}

    _config_test = {}

    @classmethod
    def config(cls, catalog, assignedpath=None):
        cls.setconfigpath(assignedpath)
        if len(cls._config_all) == 0:
            filename = os.path.join(cls.config_path, 'config.json')
            with open(filename) as json_file:
                cls._config_all = json.load(json_file)
        return cls._config_all[catalog]

    @classmethod
    def config_test(cls, catalog, assignedpath=None):
        cls.setconfigpath(assignedpath)
        if len(cls._config_test) == 0:
            filename = os.path.join(cls.config_path, 'config_test.json')
            with open(filename) as json_file:
                cls._config_test = json.load(json_file)
        return cls._config_test[catalog]

    
    @classmethod
    def reset_config_loader(cls):
        cls._config_all = {}
        cls._config_test = {}

    
    @classmethod
    def setconfigpath(cls,assignedpath=None):
        if assignedpath is None :
            if 'config_path' in os.environ.keys():
                cls.config_path = os.environ['config_path']
            else : 
                setting = cls.projectaxim() 
                if setting is not None: cls.config_path = setting
                else: cls.config_path = Path('config')
        if assignedpath is not None : 
            cls.config_path = Path(assignedpath)
        
    @classmethod
    def projectaxim(cls):
        try:
            from project import Axim as axim
            axim.__set__()
            return axim.configpath
        except:
            return None