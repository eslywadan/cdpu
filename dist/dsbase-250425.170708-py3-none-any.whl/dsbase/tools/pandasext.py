import pandas as pd

class PdExt():

  def coltype(df:pd.DataFrame,rowkey=None):
    """"
    Return by {"all":full_col_index w/o rowkey,"num":num_col_index,"str":str_col_index
                "float": numeric but not timestamp, "timestamp": timestamp}
    """
    all_cols, num_cols = PdExt.num_col(df)
    timestampcols = df.select_dtypes(include='datetime64[ns]').columns.to_list()
    float_cols = [f for f in num_cols if f not in timestampcols]
    x_cols = [x for x in all_cols if x not in rowkey]
    str_cols = [s for s in x_cols if s not in num_cols]
    return {"all":x_cols,"num":num_cols,"str":str_cols, "float":float_cols, "timestamp":timestampcols}
  
  def num_col(df:pd.DataFrame):
    num_cols = []
    all_cols = []
    for col in df.columns:
      all_cols.append(col)
      try:
        pd.to_numeric(df[col])
        num_cols.append(col)
      except ValueError:
        pass
    return all_cols, num_cols

    
