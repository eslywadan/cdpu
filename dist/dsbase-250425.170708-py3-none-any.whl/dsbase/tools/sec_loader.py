import json
import os
from dsbase.tools.config_loader import ConfigLoader

class SecretLoader:
    _secret_all = {}
    
    ConfigLoader.setconfigpath(assignedpath=None)
    config_path = ConfigLoader.config_path

    @classmethod
    def secret(cls, catalog):
        if len(cls._secret_all) == 0:
            filename = os.path.join(cls.config_path, 'secret.json')
            with open(filename) as json_file:
                cls._secret_all = json.load(json_file)
        
        return cls._secret_all[catalog]


    @classmethod
    def reset_secret_loader(cls):
        cls._secret_all = {}
