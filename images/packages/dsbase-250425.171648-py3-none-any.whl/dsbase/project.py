from pathlib import Path
class Axims():


    name = 'mdlpacks'
    cwd = Path.cwd()
    # print(f"current file path {cwd}")
    if cwd.name != name:
        i = 0 
        while cwd.parents[i].name != name:i += 1
        path = cwd.parents[i]
    else: path = cwd
    # print(f"Project root path {path}")
    configpath = Path('/') / path / 'config'
    mdlpackconfig = Path('/') / path / 'mdlpackconfig.yaml'