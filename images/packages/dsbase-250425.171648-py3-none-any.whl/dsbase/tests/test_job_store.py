from dsbase.tools.job_store import ClientJobs, redis

clientid = 'eng'

clientjobs = ClientJobs(clientid=clientid)

assert clientjobs.clientid == clientid

assert clientjobs.jobtype == 'ml365_'

## test* the maxtimelag case when the recall time is under maxtimelag
pat = "*"
all_jobs_at_start_t1 = clientjobs.get_pat_jobs_at_start(pat)
all_jobs_at_start_t2 = clientjobs.get_pat_jobs_at_start(pat)
assert all_jobs_at_start_t2 == all_jobs_at_start_t1

self = clientjobs
alljobsend = self.get_pat_jobs_at_end(pat)
alljobsprocess = self.get_pat_jobs_at_proc(pat)
res = self._keys_substract(alljobsprocess, alljobsend)
res2 = self.get_pat_jobs_in_proc()
assert res == res2

pat = "eng"
all_jobs_at_start_t3 = clientjobs.get_pat_jobs_at_start(pat)
all_jobs_at_start_t4 = clientjobs.get_pat_jobs_at_start(pat)
assert all_jobs_at_start_t2 == all_jobs_at_start_t1

jobsinproc = clientjobs.get_pat_jobs_in_proc()
alljobsinrun= clientjobs.get_all_jobs_in_run()
alljobsinstart = clientjobs.get_pat_jobs_in_start()

assert alljobsinstart == alljobsinrun  #case when there is not the 'enque' status
clientjobs.get_pat_jobs_distinct_status()
assert all(status in ['start', 'end', 'proc', 'enque'] for status  in clientjobs.distinctstatus) 

clientjobs._house_keeping_(pending_job_threshold=86400)

alljobsinstart = clientjobs.get_pat_jobs_in_start()
alljobsinrun= clientjobs.get_all_jobs_in_run()

## Case when there is not the 'enque' status right now, the assert should be True
assert alljobsinstart == alljobsinrun

clientjobsinrun = clientjobs.get_client_jobs_in_run()
clientjobinend = clientjobs.get_client_jobs_in_end()

# Test the auto repair
from dsbase.tools.job_store import ClientJobs
import json

cjs = ClientJobs('eng')

jobsinend = cjs.get_client_jobs_in_end()

for job in  jobsinend:
    jobid = f"{job}@end"
    jobinfo = cjs._get_items_by_pattern_exp(jobid)
    for k, v in jobinfo.items():
        if isinstance(v, str): print(f"{jobid} is not exploded")

