"""
   The utility function is used for naming convention applying on the cds especially on the
   dataset retrieved via data service.
   An utimate convention is exploring the query condistions as a branching tree, it is usefule to category by branching, 
   but will be lousy and needs to deep several level to get the file.
   a simplex method is using the query function name as the data set name and query time as the version 
   
"""