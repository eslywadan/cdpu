from dsbase.tools.redis_db import RedisDb
from dsbase.tools.logger import Logger
from datetime import datetime
import json
import re
import time

redis = RedisDb.default()


class ClientJobs():
    """
        a client should be able to see a window shows enque jobs also in-process jobs  
        those are using the same group's resources as the public part,  and another window
        shows it's own jobs as the private part.
        - Job Status
        1. start - Job is created 
        2. enque - Job is scheduled
        3. process - Job is working
        4. end  - Job is completed
        - Job created status
           1. fail is generally with wrong requested 
           2. success condition on correct request data
        - Job scheduled status
           1. fail on wrong resource setting
           2. success on assigned resource 
        - Job working status
           1. fail on system halt
           2. fail on process error
           3. success on processing all steps
        - Job completed status
            1. fail on system halt
            2. fail on process error
            3. success on processing all steps
        - Job end status
            1. fail on end
            2. success on end                                                                  
        A public part will show all 2 & 3 jobs

    """

    class _AllJobsStatus():
        """
            The class is used for storing the retrieval job's info, the info is retaining for reuse rather than rest if the 
            freshness of the info is in the maxlagtime.
        """
        rec_tt = {}
        now:datetime
        jobsid = {}
        max_lag_time = 0

        @classmethod
        def set_rec_tt(cls, pat):
            cls.rec_tt.update({pat:cls.now()})
        @classmethod
        def now(cls):
            return datetime.timestamp(datetime.now())
    
    class _AlljobsStart(_AllJobsStatus):
        """
        if cls.rec_tt is None: cls.rec_tt()
        elif: cls.now() - cls.rec_tt() > max_lag_time 
        """
        @classmethod
        def reset(cls, pat, maxlagtime=None):
            if maxlagtime is None: maxlagtime = cls.max_lag_time
            if pat not in cls.rec_tt.keys():
                cls.set_rec_tt(pat)
                return True
            if cls.now() - cls.rec_tt[pat] >= maxlagtime:
                return True
            return False 

    class _AlljobsEnque(_AlljobsStart):
        max_lag_time = 0

    class _AlljobsProc(_AlljobsStart):
        max_lag_time = 0

    class _AlljobsEnd(_AlljobsStart):
        max_lag_time = 0
    

    def __init__(self, clientid, jobtype="ml365_"):
        self.clientid = clientid
        self.jobtype = jobtype
        self.jobspattern = f"{jobtype}@{self.clientid}@*"
        self._set_jobs_info(self.jobspattern)

    def get_jobs_info(self):
        return self.jobsinfo
    
    def get_job_info(self, jobid):
        jobpattern = f"{jobid}*"
        return self._get_items_by_pattern(jobpattern)

    def get_all_jobs_in_run(self):
        """
        Defines all jobs in run : ("enque", 'process')
        - "enque": job id has @enque, but not @process
        - "process": job is has @process, but not @end
        """
        jobsinstart = self.get_pat_jobs_in_start()
        jobsinenque = self.get_pat_jobs_in_enque()
        jobsinproc = self.get_pat_jobs_in_proc()

        return self._keys_distinct(self._keys_distinct(jobsinenque, jobsinstart), jobsinproc)
    
    def get_client_jobs_in_run(self):
        """
        Defines all jobs in run for the client: ("enque", 'process')
        - "enque": job id has @enque, but not @process
        - "process": job is has @process, but not @end
        """
        client_pat = f"{self.clientid}*"
        jobsinstart = self.get_pat_jobs_in_start(pat=client_pat)
        jobsinenque = self.get_pat_jobs_in_enque(pat=client_pat)
        jobsinproc = self.get_pat_jobs_in_proc(pat=client_pat)

        return self._keys_distinct(self._keys_distinct(jobsinenque, jobsinstart), jobsinproc)
    
    def get_client_jobs_in_end(self):
        client_pat = f"{self.clientid}*"
        jobsinend = self.get_pat_jobs_at_end(pat=client_pat)

        return jobsinend

    def get_pat_jobs_in_start(self, pat='*'):
        """
        all jobs are in start = all jobs has @start - all jobs has @process  
        """
        alljobsstart = self.get_pat_jobs_at_start(pat)
        alljobsprocess = self.get_pat_jobs_at_proc(pat)
        alljobsend = self.get_pat_jobs_at_end(pat)
        return self._keys_substract(self._keys_substract(alljobsstart, alljobsprocess), alljobsend)

    def get_pat_jobs_in_enque(self, pat='*'):
        """
        all jobs are in enque = all jobs has @enque - all jobs has @process  
        """
        alljobsenque = self.get_pat_jobs_at_enque(pat) 
        alljobsprocess = self.get_pat_jobs_at_proc(pat)
        return self._keys_substract(alljobsenque, alljobsprocess)
    
    def get_pat_jobs_in_proc(self, pat='*'):
        """
        all jobs are in proc = all jobs has @proc - all jobs has @end  
        """
        alljobsend = self.get_pat_jobs_at_end(pat) 
        #time.sleep(0.5)
        alljobsprocess = self.get_pat_jobs_at_proc(pat)
        #time.sleep(0.5)
        return self._keys_substract(alljobsprocess, alljobsend)
    
    def get_pat_jobs_in_end(self, pat='*'):
        """
        all jobs are in end = all jobs has @end  
        """
        alljobsend = self.get_pat_jobs_at_end(pat)
        return self._keys_substract(alljobsend, [])

    def get_pat_jobs_at_start(self, pat='*'):
        if self._AlljobsStart.reset(pat):
            Logger.log(f"Reset True: Max_Time_lag is {self._AlljobsStart.max_lag_time}, the record tt is {self._AlljobsStart.rec_tt[pat]}, the actual lag time is {self._AlljobsStart.now()-self._AlljobsStart.rec_tt[pat]}")
            _alljobsstart = self._get_keys_by_pattern(pattern=f"{self.jobtype}@{pat}@start")
            alljobsstart_jobids = self._reverse_keys_to_jobids(_alljobsstart)
            self._AlljobsStart.jobsid.update({pat:alljobsstart_jobids})
            self._AlljobsStart.set_rec_tt(pat)
            return alljobsstart_jobids
        
        Logger.log(f"Reset False: Max_Time_lag is {self._AlljobsStart.max_lag_time}, the record tt is {self._AlljobsStart.rec_tt[pat]}, the actual lag time is {self._AlljobsStart.now()-self._AlljobsStart.rec_tt[pat]}")
        return self._AlljobsStart.jobsid[pat]
    
    def get_pat_jobs_at_enque(self, pat='*'):
        if self._AlljobsEnque.reset(pat):
            _alljobsenque = self._get_keys_by_pattern(pattern=f"{self.jobtype}@{pat}@enque")
            alljobsenque = self._reverse_keys_to_jobids(_alljobsenque)
            self._AlljobsEnque.jobsid.update({pat: alljobsenque})
            self._AlljobsEnque.set_rec_tt(pat)
            return alljobsenque
        return self._AlljobsEnque.jobsid[pat]
    
    def get_pat_jobs_at_proc(self, pat='*'):
        if self._AlljobsProc.reset(pat):
            _alljobsprocess = self._get_keys_by_pattern(pattern=f"{self.jobtype}@{pat}@proc")
            alljobsprocess = self._reverse_keys_to_jobids(_alljobsprocess)
            self._AlljobsProc.jobsid.update({pat:alljobsprocess})
            self._AlljobsProc.set_rec_tt(pat) 
            return alljobsprocess
        return self._AlljobsProc.jobsid[pat]
        
    def get_pat_jobs_at_end(self, pat='*'):
        if self._AlljobsEnd.reset(pat):
            _alljobsend = self._get_keys_by_pattern(pattern=f"{self.jobtype}@{pat}@end")
            alljobsend = self._reverse_keys_to_jobids(_alljobsend)
            self._AlljobsEnd.jobsid.update({pat:alljobsend})
            self._AlljobsEnd.set_rec_tt(pat)
            return alljobsend
        return self._AlljobsEnd.jobsid[pat]
    
    def get_pat_jobs_distinct_status(self,pat='*'):
        _alljobs = self._get_keys_by_pattern(pattern=f"{self.jobtype}@*")
        self.distinctstatus = self._distinct_status(_alljobs)
        return self.distinctstatus
    
    def _distinct_status(self, _jobs):
        status = []
        for job in _jobs:
            if job.split("@")[-1] not in status:
                status.append(job.split("@")[-1])
        
        return status

    def _reverse_keys_to_jobids(self, keys):
        jobids = [] 
        for key in keys:
            jobid = '@'.join(key.split('@')[:-1])
            if jobid not in jobids: jobids.append(jobid)
        return jobids

    def _keys_substract(self, keya, keyb):
        """
        Find the key in keya but not in keyb
        The last element in splitted key by '@' is job status, and the other part is the jobid
        """        
        result_key = []
        for key in keya:
            if key not in keyb: result_key.append(key)
        return result_key

    def _keys_distinct(self, keya, keyb):
        result_key = keya.copy()
        for key in keyb:
            if key not in result_key: result_key.append(key)
        return result_key

    def _set_jobs_info(self, jobspattern):
        self.jobsinfo = self._get_items_by_pattern(jobspattern)
        
    def _get_keys_by_pattern(self, pattern):
        keys = redis.redis.scan_iter(pattern)
        return list(keys)
    
    def _get_items_by_pattern(self, pattern):
        keys = redis.redis.scan_iter(pattern)
        items = {key: redis.get(key) for key in keys}
        return items
    
    def _get_items_by_pattern_exp(self, pattern, repair=True):
        """
        the function will explode the embeded dic or list for the string
        """
        items = {}
        keys = redis.redis.scan_iter(pattern)
        for key in keys:
            item = redis.get(key)
            if item is None: continue
            __ , item = ClientJobs._explode_item(item, repair)
            items.update({key:item})
        return items
    
    @classmethod
    def _explode_item(cls,item:str, repair=True):
        """
        if input item is pure string, will return 0 and original string
        if input item is dict embeded string, will loads to dic and check the items' value
        recursively. Finally return 1 and a exploded dic by json.loads
        if input item is list embeded string, will loads to list and check the items' value
        recursively, and finally return 2 and a exploded list by json.loads as well.
        The expected type of input item is string, if it is not the string, will return -1 without 
        further proceed. 
        """
        if not isinstance(item, str): return -1, f"Type of {item} is {type(item)} not str"
        try:
            explode_items = json.loads(item)
        except:
            if repair: 
                rc, rv = cls._dumps_repair(item)
                if rc == 1: 
                    #print(f"repaired value {rv}, original value {item}")
                    return cls._explode_item(rv)
                else: return 0, item
            else: return 0, item
        
        if isinstance(explode_items, dict): 
            for k, v in explode_items.items():
                explode_type, _sub_explode_item = cls._explode_item(v)
                if explode_type in [0,3] and repair:
                    rc, rv = cls._dumps_repair(v)
                    if rc == 1:
                        #print(f"repaired value {rv}, original value {v}") 
                        explode_type, _sub_explode_item = cls._explode_item(rv)
                        print(explode_type, _sub_explode_item)
                if explode_type in [1,2]: explode_items.update({k: _sub_explode_item})  
            return 1, explode_items
        
        if isinstance(explode_items, list):
            for item in explode_items:
                explode_type, _sub_explode_item = cls._explode_item(item)
                if explode_type in [0,3] and repair:
                    rc, rv = cls._dumps_repair(v)
                    if rc == 1: 
                        #print(f"repaired value {rv}, original value {v}")
                        explode_type, _sub_explode_item = cls._explode_item(rv)
                        print(explode_type, _sub_explode_item)
                if  explode_type in [1,2]: 
                    explode_items.pop(item)
                    explode_items.append(_sub_explode_item)
            return 2, explode_items
        
        if isinstance(explode_items, str) and repair: 
            rc, rv = cls._dumps_repair(explode_items)
            if rc == 1: 
                return cls._explode_item(rv)
            else: return 3, explode_items

    @classmethod
    def _dumps_repair(cls,_obj:str):
        """
        try known receipes to repair
        """
        rc, rv = cls._dumps_repair_1(_obj)
        if rc == -1:
            rc, rv = cls._next_dumps_repaire(_obj)
            if rc == -1: 
                repair_obj = cls._dumps_repaire_nested_str(_obj)
                rc, rv = cls._dumps_repair_1(repair_obj)
                if rc == -1: rc, rv = cls._next_dumps_repaire(repair_obj)
        return rc, rv
    
    @classmethod
    def _dumps_repair_1(cls,_obj:str):
        """
        repair recipe 1:
        - fix by removing the "\\"  
        """
        repair_value = _obj.replace("\'","\"").replace("\"[","[").replace("]\"","]").replace("\"{","{").replace("}\"","}").replace("\'","\"").replace("\\","")
        try: 
            json.loads(repair_value)
            print(f"repair receipe 1 success")
            return 1, repair_value
        except:
            return cls._next_dumps_repaire(_obj)
    
    @classmethod
    def _next_dumps_repaire(cls, _obj):
        """
        repair recipe 2:
        - fix by replacing ' with "
        """
        repair_value = _obj.replace("\"","\'").replace("\\","")
        try:
            json.loads(repair_value)
            print(f"repair by receipe 2 success")
            return 1, repair_value
        except:
            return cls._next_2_dumps_repaire(_obj)
    
    @classmethod
    def _next_2_dumps_repaire(cls, _obj):
        """
        repair recipe 3:
        - fix by replacing None with str
        """
        repair_value = _obj.replace("\'","\"").replace("None","-1")
        try:
            json.loads(repair_value)
            print(f"repair by receipe 3 success")
            return 1, repair_value
        except:
            return cls.__next_dumps_repaire(_obj)
    
    @classmethod
    def __next_dumps_repaire(cls, _obj):
        return -1, _obj
    
    @classmethod
    def _dumps_repaire_nested_str(cls, _obj):
        """
        repaire recipe 3
        fix probelm with nested string
        """
        nested_str_pat = r"\".*?\'.*?\'.*?\""
        repair_obj = _obj.replace("True","1").replace("False","0").replace("None","-1")
        match = re.search(nested_str_pat,repair_obj)
        while match is not None:
            segment = match.group(0)
            repaire_seg = segment.replace("\'","").replace("\"","\'")
            repair_obj = repair_obj.replace(segment, repaire_seg)
            match = re.search(nested_str_pat, repair_obj)
        
        return repair_obj
    
    @classmethod
    def update_jobid_status(cls, jobid, message:dict, status, _timestamp=True):
        """
        1. required the jobid, if not the jobid, it will return
        2. handle message type, dict or string. If dict, use json.dumps to store the info
        """
        if isinstance(message, dict):
            redis.set(f"{jobid}@{status}",json.dumps(message))
        else: return

    @classmethod
    def mdl_jobid(cls, _prefix, clientid, mdlpack ,train_data_objid):
     timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
     jobid = f"{_prefix}@{clientid}@{mdlpack}@{train_data_objid}@{timestamp}"
     return jobid
        
    def _house_keeping_(self, pending_job_threshold:int):
        """
        action 1: To clean those jobids have @start status but has not the @end status, and  
        the job create time is over past pending_job_threshold by seconds from now.
        """
        start_jobs_wo_end = self.get_all_jobs_in_run()
        _zombie_jobids = self._filter_jobs_by_create_time(start_jobs_wo_end, timethreshold=pending_job_threshold)
        if _zombie_jobids.__len__() > 0:
            for jobid in _zombie_jobids:
                self._remove_job(jobid)

    def _filter_jobs_by_create_time(self, jobs, timethreshold= 86400*3, ge=True):
        _f_jobids = []
        for job in jobs:
            job_crtime = job.split('@')[-1]
            try:
                dur = datetime.now() - datetime.strptime(job_crtime, "%Y%m%d%H%M%S")
            except ValueError:
                Logger.log("Error: The timestamp format is incorrect, please check if the suffix of job id is datetime format in '%Y%m%d%H%M%S'")
            if ge and (int(dur.total_seconds()) > timethreshold): _f_jobids.append(job)
            if not ge and (int(dur.total_seconds()) < timethreshold): _f_jobids.append(job)
        return _f_jobids 

    def _remove_job(self, jobid):
        keys = self._get_keys_by_pattern(f"*{jobid}*")
        del_list = []
        for key in keys:
            redis.redis.delete(key)
            del_list.append(key)
        
        return f"keys {del_list} are deleted"