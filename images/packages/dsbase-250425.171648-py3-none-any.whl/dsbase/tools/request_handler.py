from logging.config import valid_ident
from flask import request, render_template
from dsbase.tools.logger import Logger
from dsbase.grpc_cust.clientapival_client import get_clientapikey, get_verified_apikey
from dsbase.tools.response_handler import JSNResponse, JSNError
from dsbase.tools.config_loader import ConfigLoader
import requests
import re
from urllib.parse import urlparse 

def process_login(clientId=None, password=None):     
    if clientId is None:
        if "clientId" in request.headers:
            clientId = request.headers["clientId"]
        else:
            clientId = request.args.get('clientId')
    if password is None:
        if "password" in request.headers:
            password = request.headers["password"]
        else:
            password = request.args.get('password')

    apikey = get_clientapikey(clientId, password)

    if apikey.expiry == "1900-01-01":
        Logger.log(f"Client id {clientId} fail on process_login")
        #return JSNError(f"Client Id {clientId} or password {password} is not correct.",status_code=401)
        return { "status_code": 401, "apikey":None}
    else:
        Logger.log(f'Issue request: {clientId}, {request.method}, {request.url}')
        return {"status_code":200, "apikey":apikey.apikey}


def dummy_check_and_log():
    return  {"status":True,"apikey":"given_token"}


def check_and_log(ignore_token=False, authby="apikey"):
    """
        2025.03.26 add authby argument with 'apikey' as default
        case weh authby == 'ssotoken', will call the accountman's api (defined in config.json)
        to get the authenticated client id 
    """
    if ignore_token:
        Logger.log(f'Issue request: {request.method}, {request.url}')
        return True
   
    if authby == "ssotoken":
        request_permission = request.args.get("request_permit")
        if request_permission is None: 
            request_permission = request.url
            Logger.log(f"request_permission is not given, use the request url {request.url}")
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith('Bearer '):
            # Extract apikey from header
            given_token = auth_header.split(" ")[1]
            verify_result = get_apikey_by_ssotoken(request_permission, given_token)
            if verify_result.status_code == 200:
                _verify_result = verify_result.json()
                if isinstance(_verify_result,dict):
                    if 'clientid' and 'apikey' in _verify_result.keys():
                        _verify_result.update({"status":True})
                    else: _verify_result.update({"status":False})
                elif isinstance(_verify_result.json(),str):
                    _verify_result.update({"status":False})
                return _verify_result                  
            else:    
                return {"status":False,"error_msg":verify_result}
    
    given_token = None

    if "apikey" in request.headers: 
        given_token = request.headers["apikey"]
    # Extract authorization heder
    auth_header = request.headers.get("Authorization")
    if auth_header and auth_header.startswith('Bearer '):
        # Extract apikey from header
        given_token = auth_header.split(" ")[1]
        Logger.log(f"giveb token is via auth header in Bearer {given_token}")
    if request.args.get('token'):
        given_token = request.args.get('token')
    client_type = 'BLOCK'
    if given_token is not None:
        given_token = given_token.strip('"')
        token_info =  get_verified_apikey(given_token)
        if token_info.assertion == 'False':
            return {"status":1,"error_msg":"Given token is not correct! (無法辨識是哪一個 client id)","status_code":401}
        client_type = token_info.assertion.split(":")[1]
        Logger.log(f"{token_info} / client type {client_type}")

    if client_type == "BLOCK":
        return {"status":9,"error_msg":"Given token has found the client is blocked from requesting data services","status_code":403}

    if token_info.apikey == given_token:
        if token_info.assertion is not None:
            registry = token_info.assertion.split(":")[2]
            url_ = request.url
            granted = validate_request_reg_permit(url_, registry)
            Logger.log(f'Issue request: @{given_token}, {request.method}, {request.url}, {token_info.assertion}')
            if granted == "Permit":
                client_id = token_info.assertion.split(":")[0]
                client_prev = token_info.assertion.split(":")[2]
                return {"status":True,"apikey":given_token, "client_id":client_id}
            else:
                return {"status":2,"error_msg":"Given token has not the permission for requesting data services (該 client id 沒有此資料服務的使用權限)","status_code":403}

    Logger.log(f'Deny request: {request.method}, {request.url}')

def validate_request_reg_permit(_url,_registry):
    """
     validate if the pat math for the request url and the registry value.
     Use cate_level_reg to sep the service type and service name.
     The validate rule 1 ask the exacly same service type and then following the 
     rule 2 to be the same starting pattern and allow negative expression for the
     service name  
    """
    _service = cate_service(_url)
    granted = validate_permission(_registry, _service)
    return granted

def validate_permission(registry, _service):
    """
        The validation function will consider the wild card in the reg string
        A registry may be empty or one to several reg strings seperated by "," such as "/eng/ispec/define/F8,/eng/ispec/spec/F8"
        Generally, the registry value only defined the serviceName, but it may be strictly defined the allowed serviceType, for example,
        a registery value '/ds/carux/apds' is restricted the service type as '/ds'.
        [TODO] Thus, the registry value is detected if a leading domain definds the service type. If yes, and it is the same with input serviceType,
        it will be removed the leading domain. If yes and it is not the same with input serviceType, it will be excluded. [TODO]

        _service is a dict contains keys "serviceType" and "serviceName"
        registry is a client's registry value contains formated spec to be matched with _service.
        1. '-' Negative sign indicate the service is fobidden from the client if the registry element matched
        2. '*' allowd in the registry value
        3. if the registry has not the mapped service type will be treated as the default service (service type = 'ds')                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
    """
    
    _serviceType = _service["serviceType"]
    _serviceName = _service["serviceName"]
    permit = []
    # case registry value is empty
    if len(registry.strip())==0:  return "No Permit"
    # case registry is not empty and contains one or several regs
    for reg in registry.split(","): 
        if reg.startswith("-"): 
            reg_type = False
            reg_pat = reg.lstrip("-")
        else: 
            reg_type = True
            reg_pat = reg
        reg_service = cate_service(reg_pat)
        pat_match = None
        if reg_service["serviceType"] == _serviceType:   # Request Service Type must the same with the registry service type
            reg_service_name = reg_service["serviceName"]
            pat_match = re.search(reg_service_name.replace("*",".+"), _serviceName) 
            Logger.log(f"reg_type: {reg_type}/ reg_pat:{reg_service_name} / serviceType: {_serviceType} ")
            Logger.log(f"pat_match: {pat_match}")
        else: Logger.log(f"Has not the same service type reg_service_type: {reg_service['serviceType']} / req_service type {_serviceType}")
        if pat_match is not None and pat_match.start() == 0 and pat_match.span() != (0,0) : permit.append(reg_type)

    if permit.__len__() == 0 or permit.__contains__(False):
        return "No Permit"
    else :
        return "Permit"            

def cate_service(_url):
    """ fixing start naming rule to cate service type and service name
    _url : full path url | only path | part of path start with index 0
    (ex: http://pdatastudio.cminl.oa/ds/retrain, /ds/retrain, /ds are all allowed value)
    The function will accept the input _url and categorizes it into level 1 servier type as the key
    and the remaining part is the value as the service name 
    Because the service type is predifined string with single domain to one or serveral multiple domain,
    case when the service type is not found, it will be treated as the default service (servie type==/ds)

    service types: ["ds","retrain","ml","cds"]
    1. "ds" : _url is start with '/ds' but not in ['/ds/ml', '/ds/retrain']
    2. "retrain": url's path start with '/ds/retrain'
    3. "ml": url's path start with '/ds/ml' or '/ml'
    4. "cds": url's path start with '/cds'
    5. if not start with above, will be treated as 'ds' (stands for default service)
    return {"serviceType":servicetype,"serviceName":servicename}
    """

    path = urlparse(_url).path.strip()
    if not path.startswith("/"): path = "/" + path
    if path.startswith('/ds/ml') :  service = {"serviceType":"ml","serviceName": path.partition("/ds/ml")[2]} 
    elif path.startswith('/ml') :  service = {"serviceType":"ml","serviceName": path.partition("/ml")[2]}
    elif path.startswith('/ds/retrain') :  service = {"serviceType":"retrain","serviceName": path.partition("/ds/retrain")[2]}
    elif path.startswith('/retrain') :  service = {"serviceType":"retrain","serviceName": path.partition("/retrain")[2]}
    elif path.startswith('/ds/carux') :  service = {"serviceType":"caruxds","serviceName": path.partition("/ds/carux")[2]}
    elif path.startswith('/carux') :  service = {"serviceType":"caruxds","serviceName": path.partition("/carux")[2]}
    elif path.startswith('/ds') :  service = {"serviceType":"ds","serviceName": path.partition("/ds")[2]}
    elif path.startswith('/cds'):  service = {"serviceType":"cds","serviceName": path.partition("/cds")[2]}
    else:  service = {"serviceType":"ds","serviceName": path}
    level1_reg = service
    return level1_reg

def get_apikey_by_ssotoken(request_permision, ssotoken):
    authserver = ConfigLoader.config("accountman")
    _url=f"http://{authserver['connection']['host']}:{authserver['connection']['port']}{authserver['api']['getUserPermitsClientApikey']}"
    url = f"{_url}?request_permit={request_permision}"
    headers = {
        "Authorization": f"Bearer {ssotoken}",
        "Content-Type": "application/json"
    }
    
    Logger.log(f"get_apikey_by_ssotoken {url}")
    response = requests.get(url, headers=headers)
    Logger.log(f"get_apikey_by_ssotoken {url} with status code {response.status_code}")
    return response

def validate_ds_permission_legacy(registry, url):
    """ legacy function compared the nde and registry str in sequentially without wildcard
    """
    nde =url.partition("/ds")[2]
    permit = []
    if len(registry.strip())==0:  return "No Permit"
    for reg in registry.split(","): 
        if reg.startswith("-"):
            # Negative element, match pattern is not allowed
            if nde.startswith(reg.partition("-")[2]):permit.append(False)

        if not reg.startswith("-"):
            if nde.startswith(reg): permit.append(True)
            # consider the * as wild card and split into front and end part
            # only the first * is consider, the 2nd * will be regarded as normal string
                

    if permit.__contains__(False) or permit.__len__() == 0:
        return "No Permit"
    else :
        return "Permit"


